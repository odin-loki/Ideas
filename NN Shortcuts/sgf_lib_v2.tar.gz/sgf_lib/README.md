# Streaming Geometry Framework (SGF) — C++17 / CUDA Library

A header-only C++/CUDA implementation of the **Streaming Geometry Framework**,
unified around the **Incremental Riemannian Estimation (IRE)** primitive.

Every component is an IRE instance `(M, S, T, φ)`:
- **M** — Riemannian manifold  
- **S** — Compact sufficient statistic  
- **T** — O(1) online update  
- **φ** — Read-out of quantity of interest

---

## Structure

```
include/sgf/
├── ire.h              Core IRE CRTP base, device macros, error helpers
├── welford.cuh        Welford online statistics + LayerNorm/RMSNorm CUDA kernels
├── online_softmax.cuh Online softmax, fused cross-entropy, top-k + CUDA kernels
├── muon.cuh           Muon optimizer: Newton-Schulz orthogonalisation (CPU + cuBLAS)
├── kfac.cuh           K-FAC Kronecker factor estimator (CPU + cuBLAS/cuSolver)
├── zclip.cuh          ZClip adaptive gradient clipping + AGC (CPU + CUDA)
├── wsd.h              WSD scheduler + EoS sharpness monitor (header-only)
├── checkpoint.h       Roofline-guided checkpointing manager (CPU + GPU store)
├── moe.cuh            MoE router: top-k, expert-choice, noisy top-k + CUDA kernels
├── speculative.h      Speculative decoding controller + QQT data quality tracker
├── algebraic_layer.cuh  Autopsy-derived layers: LowRank, KWinner, Tropical, Hybrid (CPU+CUDA)
├── spectral_monitor.cuh Online α/MP/algebra classification monitors (IRE components)
└── sgf.h              Master orchestrator: all four layers unified

tests/
├── test_sgf.cpp       125-test CPU suite (no CUDA required)
└── bench_gpu.cu       GPU micro-benchmarks (Welford, LayerNorm, Softmax, MoE)

CMakeLists.txt
```

---

## IRE Component Map

| Component | Manifold M | Statistic S | Update T | Read-out φ |
|---|---|---|---|---|
| `WelfordEstimator` | ℝ | `(n, mean, M2)` | Welford eq. | `(mean, var, std)` |
| `OnlineSoftmaxState` | Δ (simplex) | `(max, sum)` | Rescale+accum | Normalise |
| `MuonOptimizerGPU` | Stiefel | EMA momentum M | EMA update | Newton-Schulz `UV^T` |
| `KFACLayer` | PSD | `(A_l, G_l)` | EMA outer product | `G^{-¼} dW A^{-¼}` |
| `ZClipState` | ℝ⁺ | Welford of ‖g‖ | Welford update | `μ + k·σ` threshold |
| `WSDScheduler` | ℝ⁺ | `(step, phase)` | Increment + check | `lr(t)` |
| `CheckpointManager` | Activation space | Checkpoint set C | Roofline policy | Recompute path |
| `MoERouter` | Expert simplex | `(G, load_ema)` | EMA dispatch | top-k selection |
| `SpeculativeDecoder` | Δ (token dist) | Draft dist q | Draft forward | Accept/reject |
| `DataQualityTracker` | Data manifold | `(quality, rep_count)` | Increment | Marginal utility |
| `LowRankLinear` | Grassmannian Gr(r,n) | `(U, V)` | Gradient on factors | `U V^T x` |
| `KWinnerLinear` | Sparse simplex | pre-activations | Top-k mask | k-hot activation |
| `TropicalLinear` | Tropical TP^{n-1} | `(max, argmax)` | O(n) max scan | `max_j(W_ij+x_j)` |
| `SpectralPowerLawMonitor` | ℝ | OLS stats (Σlogk, Σlogσ) | O(r) SV update | α power law exponent |
| `MarchenkoPasturMonitor` | PSD | `(γ, σ_noise, fro_sq)` | MP bulk partition | signal fraction |
| `AlgebraClassifier` | Alg. simplex | `(α, sig_frac, sparsity)` | EMA update | algebra scores |

---

## Build

### CPU-only (no CUDA)

```bash
mkdir build && cd build
cmake .. -DSGF_ENABLE_CUDA=OFF
make -j$(nproc)
./test_sgf_cpu
```

### With CUDA (requires CUDA 11.8+, cuBLAS, cuSolver)

```bash
mkdir build && cd build
cmake .. -DSGF_ENABLE_CUDA=ON
make -j$(nproc)
./test_sgf_cpu   # CPU tests
./bench_sgf_gpu  # GPU benchmarks
```

### Single-file include (header-only, no CMake)

```bash
g++ -std=c++17 -O3 -I/path/to/sgf_lib/include your_code.cpp -o out
# For CUDA: nvcc -std=c++17 -O3 -I/path/to/sgf_lib/include -lcublas -lcusolver your_code.cu
```

---

## Quick-Start Examples

### Welford normalisation (CPU)
```cpp
#include "sgf/welford.cuh"

sgf::WelfordEstimator w;
for (float x : data) w.observe(x);
auto r = w.readout();
printf("mean=%.4f std=%.4f\n", r.mean, r.std_dev);

// Parallel merge (distributed training — exact, no approximation)
sgf::WelfordEstimator w1, w2;
// ... fill w1, w2 on different processes ...
w1.merge(w2);  // exact Chan merge
```

### Muon optimizer step (GPU)
```cpp
#include "sgf/muon.cuh"

cublasHandle_t blas;
cublasCreate(&blas);

sgf::MuonOptimizerGPU muon;
muon.init(blas, d_model, d_ffn, /*lr=*/0.02f, /*beta=*/0.95f);

// Each training step:
muon.step(d_gradient, d_weight, stream);
// d_weight updated: w -= lr * NS(EMA(grad))
```

### ZClip + WSD (CPU)
```cpp
#include "sgf/zclip.cuh"
#include "sgf/wsd.h"

sgf::ZClipState zclip;
zclip.k = 6.0f;  // clip at mean + 6σ

sgf::WSDConfig wsd_cfg;
wsd_cfg.lr_max = 3e-4f;
wsd_cfg.warmup_steps = 500;
wsd_cfg.auto_cooldown = true;  // ZClip-triggered cooldown (SGF Prediction 2)
sgf::WSDScheduler sched(wsd_cfg);

for each step:
    float lr = sched.step(&zclip);  // ZClip feeds WSD phase detection
    bool clipped = zclip_apply_cpu(grad, n, zclip);
    // ... apply lr to optimiser ...
```

### Full orchestrator
```cpp
#include "sgf/sgf.h"

// Auto-configure for a 12-layer transformer, d=1024, ffn=4096, 8 experts
auto cfg = sgf::default_transformer_config(12, 1024, 4096, 16, 8, 3e-4f);
cfg.wsd.auto_cooldown = true;
cfg.verbose = true;

sgf::SGFOrchestrator orch(cfg);

// Training loop
for each step:
    auto report = orch.step(grads, weights);
    // report.phase, report.learning_rate, report.grad_clipped, ...
    if (report.phase == sgf::TrainingPhase::DONE) break;
```

### MoE routing (GPU)
```cpp
#include "sgf/moe.cuh"

// top_k=2, n_experts=256, n_tokens=8192
sgf::launch_moe_topk<2, 256>(d_logits, d_expert_ids, d_weights, n_tokens, stream);
sgf::launch_moe_load_update(d_expert_ids, d_load_ema, 0.99f,
                             n_tokens, 2, 256, stream);
```

### LayerNorm / RMSNorm (GPU)
```cpp
#include "sgf/welford.cuh"

// LayerNorm: [rows x cols]
sgf::launch_layernorm(d_in, d_out, d_weight, d_bias, rows, cols, 1e-5f, stream);

// RMSNorm (no mean subtraction):
sgf::launch_rmsnorm(d_in, d_out, d_weight, rows, cols, 1e-6f, stream);
```

---

## SGF Four-Layer Architecture

```
┌─────────────────────────────────────────────────────┐
│  CONTROL LAYER   MoE router · Spec-decode · QQT     │
│  Statistic: gating logits, draft dist, quality EMA  │
├─────────────────────────────────────────────────────┤
│  DYNAMICS LAYER  Muon · ZClip · WSD                 │
│  Statistic: momentum M, Welford(‖g‖), step count    │
├─────────────────────────────────────────────────────┤
│  METRIC LAYER    K-FAC · EoS monitor · Welford norm │
│  Statistic: Kronecker factors (A,G), λ_max EMA      │
├─────────────────────────────────────────────────────┤
│  PHYSICAL LAYER  Tiled matmuls · KV cache · norms   │
│  Statistic: tile (max, sum) · register-resident     │
└─────────────────────────────────────────────────────┘
```

Each layer communicates via sufficient statistics only — never raw tensors.

---

## Spectral Transform Family

The Muon component implements the full spectral transform family `G → UΣᵖVᵀ`:

| p | Transform | Optimizer |
|---|---|---|
| 1 | G (identity) | SGD |
| ½ | UΣ^½Vᵀ | Shampoo / K-FAC |
| 0 | UVᵀ | **Muon** (full whitening) |
| −½ | UΣ^{−½}Vᵀ | Exact natural gradient |
| diag 0 | sign(g) | SignSGD / Lion |

Set `muon.quintic = true` for the higher-order Newton-Schulz iteration (5 steps → closer to p=0 polar factor).

---

## Novel Predictions Implemented

| Prediction | Implementation |
|---|---|
| **P1** Muon + K-FAC synergy | `KFACLayer::precondition()` → feed output to `MuonOptimizerGPU` |
| **P2** ZClip → WSD auto-cooldown | `WSDConfig::auto_cooldown = true` + `sched.step(&zclip)` |
| **P3** EoS-adaptive checkpointing | `CheckpointManager::adapt_to_regime(EoSMonitor::regime())` |
| **P4** QQT scaling law | `DataQualityTracker::marginal_utility()` |
| **P5** Expert count vs diversity | `MoEConfig::n_experts` driven by dataset entropy |

---

## Requirements

- C++17 or later
- For CUDA kernels: CUDA 11.8+, cuBLAS, cuSolver
- No external C++ dependencies (STL only)

## License

MIT
