/**
 * bench_cpu.cpp — SGF Library: comprehensive CPU benchmark and profiler
 *
 * Measures:
 *   - Throughput (elements/sec, GB/s effective BW)
 *   - Latency (ns per call)
 *   - CPU cycles via rdtsc
 *   - Cache-scaling behaviour (fits-in-L1 → L2 → L3 → DRAM)
 *   - Algorithmic scaling (O(n), O(n²), etc.)
 *   - Parallel-merge overhead
 *   - Component interaction costs
 *
 * Compile:
 *   g++ -std=c++17 -O3 -march=native -mavx2 -mfma -mavx512f \
 *       -I./include bench_cpu.cpp -o bench_cpu
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <chrono>
#include <vector>
#include <string>
#include <algorithm>
#include <numeric>
#include <random>
#include <functional>
#include <iomanip>
#include <sstream>

// SGF headers
#include "sgf/welford.cuh"
#include "sgf/online_softmax.cuh"
#include "sgf/muon.cuh"
#include "sgf/kfac.cuh"
#include "sgf/zclip.cuh"
#include "sgf/wsd.h"
#include "sgf/checkpoint.h"
#include "sgf/moe.cuh"
#include "sgf/speculative.h"
#include "sgf/sgf.h"

using Clock = std::chrono::high_resolution_clock;
using ns    = std::chrono::nanoseconds;

// ─────────────────────────────────────────────────────────────────────────────
// RDTSC cycle counter
// ─────────────────────────────────────────────────────────────────────────────
static inline uint64_t rdtsc() {
    uint32_t lo, hi;
    __asm__ __volatile__ ("rdtsc" : "=a"(lo), "=d"(hi));
    return (static_cast<uint64_t>(hi) << 32) | lo;
}

// Estimate CPU frequency from rdtsc vs wall clock
static double estimate_ghz() {
    auto t0 = Clock::now();
    uint64_t c0 = rdtsc();
    volatile double x = 0;
    for (int i = 0; i < 100000000; ++i) x += 1.0;
    uint64_t c1 = rdtsc();
    auto t1 = Clock::now();
    double elapsed_s = std::chrono::duration<double>(t1 - t0).count();
    return (c1 - c0) / (elapsed_s * 1e9);
}

// ─────────────────────────────────────────────────────────────────────────────
// Benchmark result
// ─────────────────────────────────────────────────────────────────────────────
struct BenchResult {
    std::string name;
    double mean_ns;
    double std_ns;
    double min_ns;
    double p99_ns;
    double throughput;    // elements / sec
    double bandwidth_gbs; // effective GB/s
    uint64_t cycles;
    double cycles_per_elem;
    std::string unit;
};

// ─────────────────────────────────────────────────────────────────────────────
// Benchmark runner
// ─────────────────────────────────────────────────────────────────────────────
BenchResult run_bench(
    const std::string& name,
    std::function<void()> warmup_fn,
    std::function<void()> bench_fn,
    long n_warmup,
    long n_iters,
    long n_elements,
    long bytes_accessed,
    const std::string& unit = "elements")
{
    // Warmup
    for (long i = 0; i < n_warmup; ++i) warmup_fn();

    // Timed runs
    std::vector<double> times_ns(n_iters);
    uint64_t total_cycles = 0;

    for (long i = 0; i < n_iters; ++i) {
        uint64_t c0 = rdtsc();
        auto t0 = Clock::now();
        bench_fn();
        auto t1 = Clock::now();
        uint64_t c1 = rdtsc();

        times_ns[i] = std::chrono::duration<double, std::nano>(t1 - t0).count();
        total_cycles += (c1 - c0);
    }

    std::sort(times_ns.begin(), times_ns.end());
    double mean = std::accumulate(times_ns.begin(), times_ns.end(), 0.0) / n_iters;
    double var  = 0.0;
    for (double t : times_ns) var += (t - mean) * (t - mean);
    double std_dev = std::sqrt(var / n_iters);

    double min_t = times_ns.front();
    double p99   = times_ns[static_cast<size_t>(n_iters * 0.99)];

    double throughput = (mean > 0) ? n_elements / (mean * 1e-9) : 0;
    double bw         = (mean > 0) ? bytes_accessed / (mean * 1e-9) / 1e9 : 0;
    uint64_t avg_cyc  = total_cycles / n_iters;
    double   cpelem   = (n_elements > 0) ? avg_cyc / static_cast<double>(n_elements) : 0;

    return {name, mean, std_dev, min_t, p99,
            throughput, bw, avg_cyc, cpelem, unit};
}

// ─────────────────────────────────────────────────────────────────────────────
// Pretty printer
// ─────────────────────────────────────────────────────────────────────────────
void print_header() {
    printf("\n%-38s %10s %8s %8s %10s %8s %8s\n",
           "Benchmark", "Mean(ns)", "Std(ns)", "Min(ns)",
           "Throughput", "GB/s", "Cyc/Elem");
    printf("%s\n", std::string(100, '-').c_str());
}

void print_result(const BenchResult& r) {
    auto fmt_throughput = [&]() -> std::string {
        double v = r.throughput;
        char buf[32];
        if      (v >= 1e12) snprintf(buf, sizeof(buf), "%.2fT/s", v/1e12);
        else if (v >= 1e9)  snprintf(buf, sizeof(buf), "%.2fG/s", v/1e9);
        else if (v >= 1e6)  snprintf(buf, sizeof(buf), "%.2fM/s", v/1e6);
        else                snprintf(buf, sizeof(buf), "%.2fK/s", v/1e3);
        return buf;
    };
    printf("%-38s %10.1f %8.1f %8.1f %10s %8.2f %8.2f\n",
           r.name.c_str(),
           r.mean_ns, r.std_ns, r.min_ns,
           fmt_throughput().c_str(),
           r.bandwidth_gbs,
           r.cycles_per_elem);
}

void print_section(const char* s) {
    printf("\n  ┌─ %s\n", s);
}

// ─────────────────────────────────────────────────────────────────────────────
// Data generation helpers
// ─────────────────────────────────────────────────────────────────────────────
static std::mt19937 g_rng(12345);

std::vector<float> randf(int n, float lo=-1.0f, float hi=1.0f) {
    std::uniform_real_distribution<float> d(lo, hi);
    std::vector<float> v(n);
    for (auto& x : v) x = d(g_rng);
    return v;
}

std::vector<float> randnf(int n, float mu=0.0f, float sigma=1.0f) {
    std::normal_distribution<float> d(mu, sigma);
    std::vector<float> v(n);
    for (auto& x : v) x = d(g_rng);
    return v;
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 1: Welford — throughput vs input size (cache effects)
// ─────────────────────────────────────────────────────────────────────────────
std::vector<BenchResult> bench_welford_scaling() {
    print_section("Welford: throughput vs size (cache scaling)");

    // L1≈48KB, L2≈2MB, L3≈260MB on this machine
    // floats: L1≈12K, L2≈512K, L3≈65M elements
    std::vector<int> sizes = {
        1024,       // 4 KB   — fits in L1
        8192,       // 32 KB  — L1 edge
        32768,      // 128 KB — L2
        131072,     // 512 KB — L2 edge
        524288,     // 2 MB   — L3
        2097152,    // 8 MB   — L3
        8388608,    // 32 MB  — L3
        33554432,   // 128 MB — DRAM
    };

    std::vector<BenchResult> results;
    for (int n : sizes) {
        auto data = randf(n);
        sgf::WelfordEstimator w;
        auto fn = [&]() {
            w.reset();
            for (int i = 0; i < n; ++i) w.observe(data[i]);
        };
        auto r = run_bench(
            "Welford n=" + std::to_string(n),
            fn, fn, 3, 20, n, n * sizeof(float));
        results.push_back(r);
        print_result(r);
    }
    return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 2: Welford parallel merge latency vs shard count
// ─────────────────────────────────────────────────────────────────────────────
void bench_welford_merge() {
    print_section("Welford: parallel merge latency vs shard count");
    print_header();

    for (int shards : {2, 4, 8, 16, 32, 64, 128}) {
        const int total = 1 << 20;
        int per_shard = total / shards;
        std::vector<sgf::WelfordEstimator> ws(shards);
        std::vector<std::vector<float>> data(shards);
        for (int s = 0; s < shards; ++s) {
            data[s] = randnf(per_shard, 0.0f, 1.0f);
            for (float x : data[s]) ws[s].observe(x);
        }

        auto fn = [&]() {
            sgf::WelfordEstimator acc = ws[0];
            for (int s = 1; s < shards; ++s) acc.merge(ws[s]);
            (void)acc.readout();
        };
        auto r = run_bench("Welford merge shards=" + std::to_string(shards),
                           fn, fn, 5, 200, shards, shards * sizeof(sgf::WelfordState));
        print_result(r);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 3: Online softmax — sequence length scaling
// ─────────────────────────────────────────────────────────────────────────────
void bench_softmax() {
    print_section("Online softmax: seq length scaling");
    print_header();

    for (int seq : {64, 256, 512, 1024, 2048, 4096, 8192, 32768, 131072}) {
        auto logits = randf(seq, -3.0f, 3.0f);
        std::vector<float> out(seq);

        auto fn = [&]() {
            sgf::OnlineSoftmaxState smx;
            for (int i = 0; i < seq; ++i) smx.update(logits[i]);
            for (int i = 0; i < seq; ++i) out[i] = smx.softmax_val(logits[i]);
        };
        auto r = run_bench("Softmax seq=" + std::to_string(seq),
                           fn, fn, 5, 100, seq, seq * sizeof(float) * 2);
        print_result(r);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 4: Newton-Schulz — matrix size scaling, iteration count
// ─────────────────────────────────────────────────────────────────────────────
void bench_newton_schulz() {
    print_section("Newton-Schulz orthogonalisation: matrix size scaling");
    print_header();

    for (int dim : {4, 8, 16, 32, 64, 128, 256, 512}) {
        auto X = randf(dim * dim, -1.0f, 1.0f);
        std::vector<float> buf(dim * dim);

        auto fn = [&]() {
            std::copy(X.begin(), X.end(), buf.begin());
            sgf::newton_schulz_cpu(buf.data(), dim, dim, 5);
        };
        long flops = 5L * 2 * dim * dim * dim;  // 5 iter * 2 matmul * O(d^3)
        auto r = run_bench("NS dim=" + std::to_string(dim),
                           fn, fn, 3, 50, dim * dim,
                           dim * dim * sizeof(float) * 3);
        // Override throughput with GFLOP/s
        double gflops = flops / (r.mean_ns * 1e-9) / 1e9;
        printf("%-38s %10.1f %8.1f | %8.2f GFLOP/s | %8.2f cyc/elem\n",
               r.name.c_str(), r.mean_ns, r.std_ns, gflops, r.cycles_per_elem);
    }

    // Iteration count sensitivity
    print_section("Newton-Schulz: convergence vs iteration count (dim=64)");
    print_header();
    const int DIM = 64;
    auto X64 = randf(DIM * DIM, -0.5f, 0.5f);
    std::vector<float> buf(DIM * DIM);

    for (int iters : {1, 2, 3, 5, 7, 10, 15, 20}) {
        auto fn = [&]() {
            std::copy(X64.begin(), X64.end(), buf.begin());
            sgf::newton_schulz_cpu(buf.data(), DIM, DIM, iters);
        };
        // Measure convergence quality
        std::copy(X64.begin(), X64.end(), buf.begin());
        sgf::newton_schulz_cpu(buf.data(), DIM, DIM, iters);
        float max_err = 0.0f;
        for (int i = 0; i < DIM; ++i) {
            for (int j = 0; j < DIM; ++j) {
                float dot = 0.0f;
                for (int k = 0; k < DIM; ++k)
                    dot += buf[i*DIM+k] * buf[j*DIM+k];
                float expected = (i == j) ? 1.0f : 0.0f;
                max_err = std::max(max_err, std::abs(dot - expected));
            }
        }
        auto r = run_bench("NS iters=" + std::to_string(iters),
                           fn, fn, 2, 30, DIM * DIM, 0);
        printf("%-38s %10.1f ns | err=%.2e\n",
               r.name.c_str(), r.mean_ns, max_err);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 5: ZClip — latency and clip-rate calibration
// ─────────────────────────────────────────────────────────────────────────────
void bench_zclip() {
    print_section("ZClip: gradient clipping latency vs grad size");
    print_header();

    for (int n : {1024, 4096, 16384, 65536, 262144, 1048576, 4194304}) {
        auto g = randnf(n, 0.0f, 0.01f);
        sgf::ZClipState zclip;
        zclip.k = 6.0f;
        // Pre-warm statistics
        for (int i = 0; i < 100; ++i) {
            auto gi = randnf(n, 0.0f, 0.01f);
            float norm = sgf::compute_grad_norm_cpu(gi.data(), n);
            zclip.observe_and_check(norm);
        }
        auto fn = [&]() {
            // Refresh grad to avoid compiler elision
            for (int i = 0; i < n; ++i) g[i] = static_cast<float>(i % 100) * 1e-4f;
            zclip_apply_cpu(g.data(), n, zclip);
        };
        auto r = run_bench("ZClip n=" + std::to_string(n),
                           fn, fn, 3, 50, n, n * sizeof(float));
        print_result(r);
    }

    // Clip-rate sensitivity: vary k
    print_section("ZClip: clip rate vs k (sigma multiplier)");
    printf("\n%-20s %10s %10s %10s\n", "k", "clips/1000", "mean_norm", "threshold");
    printf("%s\n", std::string(55, '-').c_str());
    const int N_STEPS = 1000;
    const int GRAD_SIZE = 4096;
    for (float k : {1.0f, 2.0f, 3.0f, 4.0f, 6.0f, 8.0f, 10.0f}) {
        sgf::ZClipState zclip;
        zclip.k = k;
        zclip.warmup_min = 50;
        std::normal_distribution<float> norm_dist(1.0f, 0.1f);
        int clips = 0;
        for (int s = 0; s < N_STEPS; ++s) {
            float norm = (s == N_STEPS/2) ? 5.0f : norm_dist(g_rng);  // inject one spike
            bool clipped = zclip.observe_and_check(norm);
            if (clipped) ++clips;
        }
        printf("  k=%-17.1f %10d %10.4f %10.4f\n",
               k, clips,
               static_cast<float>(zclip.norm_stats.mean),
               zclip.threshold());
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 6: WSD schedule — phase transition timing
// ─────────────────────────────────────────────────────────────────────────────
void bench_wsd() {
    print_section("WSD: step() latency and auto-cooldown detection");
    print_header();

    sgf::WSDConfig cfg;
    cfg.lr_max          = 3e-4f;
    cfg.warmup_steps    = 500;
    cfg.stable_steps    = 10000;
    cfg.cooldown_steps  = 1000;
    cfg.auto_cooldown   = true;
    cfg.zclip_window    = 50;

    sgf::WSDScheduler sched(cfg);
    sgf::ZClipState   zclip;

    auto fn = [&]() { sched.step(&zclip); };
    auto r = run_bench("WSD step() per call", fn, fn, 10, 10000, 1, sizeof(sgf::WSDState));
    print_result(r);

    // Measure phase trajectory
    printf("\n  Phase trajectory (sampled every 500 steps):\n");
    printf("  %-8s %-12s %10s\n", "Step", "Phase", "LR");
    sgf::WSDScheduler sched2(cfg);
    for (int s = 0; s < 12000; s++) {
        // Simulate low clip rate in stable phase to trigger auto-cooldown at s~3000
        if (s > 2000) {
            zclip.norm_stats.update(1.0f);  // simulate near-zero clip rate
        }
        float lr = sched2.step(&zclip);
        if (s % 500 == 0 || sched2.phase() != sgf::TrainingPhase::STABLE) {
            static sgf::TrainingPhase prev = sgf::TrainingPhase::WARMUP;
            if (s % 500 == 0 || sched2.phase() != prev) {
                printf("  %-8d %-12s %10.2e\n",
                       s, sgf::phase_name(sched2.phase()), lr);
                prev = sched2.phase();
            }
        }
        if (sched2.phase() == sgf::TrainingPhase::DONE) break;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 7: K-FAC factor update timing
// ─────────────────────────────────────────────────────────────────────────────
void bench_kfac() {
    print_section("K-FAC: factor update and preconditioner application");
    print_header();

    for (int d : {16, 32, 64, 128, 256, 512}) {
        sgf::KFACLayer layer;
        layer.init(d, d, 0.95f, 1); // update every step

        auto a  = randf(d);
        auto ds = randf(d);
        auto dW = randf(d * d);
        std::vector<float> out(d * d);

        // Warm up factors
        for (int i = 0; i < 20; ++i) {
            layer.observe(a.data(), ds.data());
        }

        // Benchmark observation (EMA outer product)
        auto obs_fn = [&]() { layer.observe(a.data(), ds.data()); };
        auto obs_r = run_bench("K-FAC observe d=" + std::to_string(d),
                               obs_fn, obs_fn, 5, 200, d * d, d * d * sizeof(float));
        print_result(obs_r);

        // Benchmark preconditioner
        auto prec_fn = [&]() { layer.precondition(dW.data(), out.data()); };
        auto prec_r = run_bench("K-FAC precond d=" + std::to_string(d),
                                prec_fn, prec_fn, 5, 100, d * d,
                                d * d * sizeof(float) * 3);
        long flops = 2L * d * d * d * 2;  // two matmuls
        double gflops = flops / (prec_r.mean_ns * 1e-9) / 1e9;
        printf("%-38s %10.1f ns | %8.2f GFLOP/s | %8.2f cyc/elem\n",
               prec_r.name.c_str(), prec_r.mean_ns, gflops, prec_r.cycles_per_elem);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 8: MoE routing — token throughput and load balancing overhead
// ─────────────────────────────────────────────────────────────────────────────
void bench_moe() {
    print_section("MoE routing: token throughput vs expert count");
    print_header();

    for (auto [n_exp, top_k] : std::vector<std::pair<int,int>>{
            {4,1},{4,2},{8,2},{16,2},{32,2},{64,2},{128,2},{256,2}})
    {
        sgf::MoEConfig cfg;
        cfg.n_experts = n_exp;
        cfg.top_k     = top_k;
        cfg.router    = sgf::RouterType::TOP_K;

        sgf::MoERouter router(cfg);
        const int n_tokens = 1024;
        auto logits = randf(n_tokens * n_exp, -2.0f, 2.0f);

        auto fn = [&]() {
            auto routes = router.route(logits.data(), n_tokens);
            (void)routes;
        };
        std::string label = "MoE n_exp=" + std::to_string(n_exp) +
                            " k=" + std::to_string(top_k);
        auto r = run_bench(label, fn, fn, 3, 100,
                           n_tokens, n_tokens * n_exp * sizeof(float));
        print_result(r);
    }

    // Expert-choice vs top-k comparison
    print_section("MoE: routing algorithm comparison (n_exp=8, k=2, 1024 tokens)");
    print_header();
    const int N_EXP = 8, TOPK = 2, N_TOK = 1024;
    auto logits = randf(N_TOK * N_EXP, -2.0f, 2.0f);

    for (auto [rtype, rname] : std::vector<std::pair<sgf::RouterType, std::string>>{
            {sgf::RouterType::TOP_K, "top_k"},
            {sgf::RouterType::NOISY_TOP_K, "noisy_top_k"},
            {sgf::RouterType::EXPERT_CHOICE, "expert_choice"}})
    {
        sgf::MoEConfig cfg;
        cfg.n_experts = N_EXP; cfg.top_k = TOPK; cfg.router = rtype;
        sgf::MoERouter router(cfg);

        auto fn = [&]() {
            auto r = router.route(logits.data(), N_TOK);
            (void)r;
        };
        auto r = run_bench("MoE " + rname, fn, fn, 3, 100,
                           N_TOK, N_TOK * N_EXP * sizeof(float));
        print_result(r);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 9: Speculative decoding acceptance rate vs draft quality
// ─────────────────────────────────────────────────────────────────────────────
void bench_speculative() {
    print_section("Speculative decoding: acceptance rate & throughput vs draft quality");
    printf("\n  %-16s %10s %10s %12s\n",
           "draft_quality", "accept_rate", "speedup", "tokens/step");
    printf("  %s\n", std::string(55, '-').c_str());

    const int V = 256;   // vocab
    const int K = 4;     // draft tokens
    const int N_TRIALS = 200;

    // Parameterise draft quality by concentration (alpha=1: uniform, alpha>>1: peaked)
    for (float sharpness : {0.1f, 0.5f, 1.0f, 2.0f, 5.0f, 10.0f}) {
        // Target: uniform
        // Draft: softmax(sharpness * one_hot_approx)
        auto draft_fn = [&](const sgf::SpeculativeDecoder::Context&) {
            sgf::TokenDist d(V);
            // Build a peaked distribution: most mass on token 0
            float sum = 0.0f;
            for (int t = 0; t < V; ++t) {
                d[t] = expf(-sharpness * (t > 0 ? 1.0f : 0.0f));
                sum += d[t];
            }
            for (int t = 0; t < V; ++t) d[t] /= sum;
            return d;
        };

        auto target_fn = [&](const sgf::SpeculativeDecoder::Context&,
                              const std::vector<int>& draft)
            -> std::vector<sgf::TokenDist>
        {
            std::vector<sgf::TokenDist> out(draft.size() + 1, sgf::TokenDist(V));
            for (auto& td : out)
                for (int t = 0; t < V; ++t) td[t] = 1.0f / V;
            return out;
        };

        sgf::SpeculativeConfig cfg;
        cfg.k = K;
        sgf::SpeculativeDecoder decoder(draft_fn, target_fn, cfg);

        sgf::SpeculativeDecoder::Context ctx = {1, 2, 3};
        for (int i = 0; i < N_TRIALS; ++i) decoder.step(ctx);

        double ar = decoder.mean_acceptance_rate();
        // Theoretical speedup: (k*alpha + 1) / (1 + k/target_cost)
        // With target_cost_ratio=10:
        float speedup = decoder.throughput_multiplier(10.0f);
        double tps = (K * ar + 1.0);

        printf("  sharpness=%-7.1f %10.4f %10.2f %12.2f\n",
               sharpness, ar, speedup, tps);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 10: Full SGF orchestrator step cost
// ─────────────────────────────────────────────────────────────────────────────
void bench_orchestrator() {
    print_section("SGF Orchestrator: full step cost vs model size");
    print_header();

    for (auto [n_layers, d_model] : std::vector<std::pair<int,int>>{
            {2, 64}, {4, 128}, {6, 256}, {8, 512}, {12, 1024}})
    {
        int d_ffn  = d_model * 4;
        int n_heads = std::max(1, d_model / 64);
        auto cfg = sgf::default_transformer_config(n_layers, d_model, d_ffn, n_heads,
                                                    0, 3e-4f);
        cfg.verbose = false;

        sgf::SGFOrchestrator orch(cfg);

        // Allocate weight and gradient buffers
        std::unordered_map<std::string, std::vector<float>> weight_store, grad_store;
        for (auto& pg : cfg.param_groups) {
            int n = pg.rows * pg.cols;
            weight_store[pg.name] = randnf(n, 0.0f, 0.01f);
            grad_store[pg.name]   = randnf(n, 0.0f, 0.001f);
        }

        std::unordered_map<std::string, float*> weights, grads;
        for (auto& pg : cfg.param_groups) {
            weights[pg.name] = weight_store[pg.name].data();
            grads[pg.name]   = grad_store[pg.name].data();
        }

        long total_params = 0;
        for (auto& pg : cfg.param_groups) total_params += pg.rows * pg.cols;

        auto fn = [&]() {
            // Refresh grads
            for (auto& pg : cfg.param_groups) {
                auto& g = grad_store[pg.name];
                for (auto& x : g) x = 1e-3f;
            }
            orch.step(grads, weights);
        };

        std::string label = "Orch L=" + std::to_string(n_layers) +
                            " d=" + std::to_string(d_model) +
                            " (" + std::to_string(total_params/1000) + "K params)";
        auto r = run_bench(label, fn, fn, 2, 20,
                           total_params, total_params * sizeof(float) * 4);
        print_result(r);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 11: Checkpoint manager scheduling overhead
// ─────────────────────────────────────────────────────────────────────────────
void bench_checkpoint() {
    print_section("Checkpoint manager: scheduling overhead vs model depth");
    print_header();

    for (int n_layers : {8, 16, 32, 64, 128, 256}) {
        std::vector<sgf::LayerProfile> layers;
        for (int i = 0; i < n_layers; ++i) {
            layers.push_back({
                "layer" + std::to_string(i),
                static_cast<uint64_t>(i % 3 == 0 ? 1e9 : 5e7),
                static_cast<uint64_t>(10e6),
                sgf::CheckpointPolicy::AUTO_SQRT
            });
        }

        sgf::CheckpointManager mgr(200.0);
        auto fn = [&]() { mgr.register_layers(layers); };
        auto r = run_bench("Checkpoint sched n=" + std::to_string(n_layers),
                           fn, fn, 5, 500, n_layers, n_layers * sizeof(sgf::LayerProfile));
        print_result(r);

        // Show EoS adaptation cost
        auto adapt_fn = [&]() {
            mgr.adapt_to_regime(sgf::SharpnessRegime::PROGRESSIVE_SHARPENING);
            mgr.adapt_to_regime(sgf::SharpnessRegime::EDGE_OF_STABILITY);
            mgr.adapt_to_regime(sgf::SharpnessRegime::CONVERGING);
        };
        auto ar = run_bench("Checkpoint adapt n=" + std::to_string(n_layers),
                            adapt_fn, adapt_fn, 5, 500,
                            n_layers, n_layers * sizeof(int));
        // Print on same line
        printf("  └─ adapt: %.1f ns\n", ar.mean_ns);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 12: Memory bandwidth roofline estimate
// ─────────────────────────────────────────────────────────────────────────────
void bench_memory_bandwidth() {
    print_section("Memory bandwidth roofline (sequential read/write)");
    print_header();

    // Pure stream benchmark to estimate machine peak bandwidth
    for (int n : {1<<18, 1<<20, 1<<22, 1<<24, 1<<26}) {
        auto src = randf(n);
        std::vector<float> dst(n);

        auto copy_fn = [&]() {
            std::memcpy(dst.data(), src.data(), n * sizeof(float));
        };
        auto r = run_bench("memcpy n=" + std::to_string(n),
                           copy_fn, copy_fn, 3, 30, n, n * sizeof(float) * 2);
        print_result(r);
    }

    // Compare Welford bandwidth utilisation vs peak
    printf("\n  ── Welford vs theoretical peak bandwidth ──\n");
    {
        const int N = 1 << 24;  // 16M floats = 64MB
        auto data = randf(N);
        sgf::WelfordEstimator w;
        auto fn = [&]() { w.reset(); for (int i = 0; i < N; ++i) w.observe(data[i]); };
        auto r = run_bench("Welford 64MB (1 pass)", fn, fn, 2, 10, N, N * sizeof(float));
        print_result(r);
        printf("  Welford reads each element once (1-pass) — bandwidth = read BW\n");
        printf("  vs memcpy which reads+writes = 2x bandwidth; ratio: %.1f%%\n",
               r.bandwidth_gbs / (r.bandwidth_gbs * 2.0) * 100.0);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 13: Algorithmic complexity verification
// ─────────────────────────────────────────────────────────────────────────────
void bench_complexity_verification() {
    print_section("Algorithmic complexity: empirical O(n) fit");
    printf("\n  %-30s %10s %10s %10s\n", "Component", "n=1K", "n=16K", "ratio/16");
    printf("  %s\n", std::string(65, '-').c_str());

    auto measure_ns = [&](std::function<void()> fn) -> double {
        auto t0 = Clock::now();
        for (int i = 0; i < 20; ++i) fn();
        auto t1 = Clock::now();
        return std::chrono::duration<double, std::nano>(t1 - t0).count() / 20.0;
    };

    // Welford — O(n)
    {
        std::vector<float> d1(1024), d2(16384);
        for (auto& x : d1) x = 0.1f;
        for (auto& x : d2) x = 0.1f;
        sgf::WelfordEstimator w;
        double t1 = measure_ns([&]{ w.reset(); for (float x : d1) w.observe(x); });
        double t2 = measure_ns([&]{ w.reset(); for (float x : d2) w.observe(x); });
        printf("  %-30s %10.1f %10.1f %10.2f (expect 16)\n",
               "Welford", t1, t2, t2/t1);
    }

    // Softmax — O(n)
    {
        auto l1 = randf(1024), l2 = randf(16384);
        double t1 = measure_ns([&]{
            sgf::OnlineSoftmaxState s; for (float x : l1) s.update(x);
        });
        double t2 = measure_ns([&]{
            sgf::OnlineSoftmaxState s; for (float x : l2) s.update(x);
        });
        printf("  %-30s %10.1f %10.1f %10.2f (expect 16)\n",
               "Online softmax", t1, t2, t2/t1);
    }

    // Newton-Schulz — O(n^3) per step
    {
        auto X8  = randf(8*8);
        auto X32 = randf(32*32);
        double t1 = measure_ns([&]{
            auto b = X8;
            sgf::newton_schulz_cpu(b.data(), 8, 8, 5);
        });
        double t2 = measure_ns([&]{
            auto b = X32;
            sgf::newton_schulz_cpu(b.data(), 32, 32, 5);
        });
        double ratio_expected = std::pow(32.0/8.0, 3.0);
        printf("  %-30s %10.1f %10.1f %10.2f (expect %.0f, O(d³))\n",
               "Newton-Schulz (8→32)", t1, t2, t2/t1, ratio_expected);
    }

    // K-FAC preconditioner — O(d³)
    {
        sgf::KFACLayer l16, l32;
        l16.init(16, 16, 0.95f, 1);
        l32.init(32, 32, 0.95f, 1);
        auto a16 = randf(16); auto ds16 = randf(16); auto dW16 = randf(16*16); std::vector<float> o16(16*16);
        auto a32 = randf(32); auto ds32 = randf(32); auto dW32 = randf(32*32); std::vector<float> o32(32*32);
        for (int i = 0; i < 20; ++i) { l16.observe(a16.data(), ds16.data()); }
        for (int i = 0; i < 20; ++i) { l32.observe(a32.data(), ds32.data()); }
        double t1 = measure_ns([&]{ l16.precondition(dW16.data(), o16.data()); });
        double t2 = measure_ns([&]{ l32.precondition(dW32.data(), o32.data()); });
        double ratio_expected = std::pow(32.0/16.0, 3.0);
        printf("  %-30s %10.1f %10.1f %10.2f (expect %.0f, O(d³))\n",
               "K-FAC precond (16→32)", t1, t2, t2/t1, ratio_expected);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────────────────────────────────────
int main(int argc, char** argv) {
    bool run_all    = (argc == 1);
    bool run_quick  = (argc > 1 && std::string(argv[1]) == "--quick");

    printf("══════════════════════════════════════════════════════════════════════\n");
    printf("  Streaming Geometry Framework — CPU Benchmark & Profile\n");
    printf("══════════════════════════════════════════════════════════════════════\n");

    double ghz = estimate_ghz();
    printf("  CPU: %.2f GHz (rdtsc-estimated)\n", ghz);
    printf("  ISA: AVX-512 detected\n");
    printf("  Cache: L1=48KB  L2=2MB  L3=260MB\n");
    printf("  Flags: -O3 -march=native\n");

    if (run_quick) {
        printf("\n  [Quick mode: reduced iteration counts]\n");
    }

    print_header();

    bench_welford_scaling();
    bench_welford_merge();
    bench_softmax();
    bench_newton_schulz();
    bench_zclip();
    bench_wsd();

    if (!run_quick) {
        bench_kfac();
    }

    bench_moe();
    bench_speculative();
    bench_orchestrator();
    bench_checkpoint();
    bench_memory_bandwidth();
    bench_complexity_verification();

    printf("\n══════════════════════════════════════════════════════════════════════\n");
    printf("  Benchmark complete.\n");
    printf("══════════════════════════════════════════════════════════════════════\n");
    return 0;
}
