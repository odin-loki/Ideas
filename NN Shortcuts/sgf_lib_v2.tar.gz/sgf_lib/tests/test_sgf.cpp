/**
 * tests/test_sgf.cpp — SGF library unit tests (CPU-only, no CUDA required)
 *
 * Compile: g++ -std=c++17 -O2 -I../include test_sgf.cpp -o test_sgf
 * Run:     ./test_sgf
 */

#include <cstdio>
#include <cmath>
#include <cassert>
#include <vector>
#include <string>
#include <numeric>
#include <random>
#include <cstring>
#include <unordered_map>

// Pull in all SGF headers (CPU portions only)
#include "sgf/welford.cuh"
#include "sgf/online_softmax.cuh"
#include "sgf/muon.cuh"
#include "sgf/zclip.cuh"
#include "sgf/wsd.h"
#include "sgf/checkpoint.h"
#include "sgf/moe.cuh"
#include "sgf/speculative.h"
#include "sgf/sgf.h"

// ─────────────────────────────────────────────────────────────────────────────
// Minimal test framework
// ─────────────────────────────────────────────────────────────────────────────
static int g_pass = 0, g_fail = 0;

#define EXPECT_NEAR(a, b, tol) \
    do { \
        double _a = (a), _b = (b), _t = (tol); \
        if (std::abs(_a - _b) <= _t) { \
            ++g_pass; \
        } else { \
            fprintf(stderr, "FAIL [%s:%d] %s ≈ %s  got %.8g vs %.8g (tol %.2g)\n", \
                    __FILE__, __LINE__, #a, #b, _a, _b, _t); \
            ++g_fail; \
        } \
    } while (0)

#define EXPECT_TRUE(cond) \
    do { \
        if (cond) { ++g_pass; } \
        else { fprintf(stderr, "FAIL [%s:%d] %s\n", __FILE__, __LINE__, #cond); ++g_fail; } \
    } while (0)

#define SECTION(name) printf("\n── %s ──\n", name)

// ─────────────────────────────────────────────────────────────────────────────
// 1. Welford
// ─────────────────────────────────────────────────────────────────────────────
void test_welford() {
    SECTION("Welford online statistics");

    sgf::WelfordEstimator w;
    std::vector<double> data = {2.0, 4.0, 4.0, 4.0, 5.0, 5.0, 7.0, 9.0};
    for (double x : data) w.observe(x);

    auto r = w.readout();
    EXPECT_NEAR(r.mean,     5.0, 1e-9);   // known mean
    EXPECT_NEAR(r.variance, 4.571428571, 1e-6);  // sample variance
    EXPECT_NEAR(r.std_dev,  2.138089935, 1e-6);  // sample std

    // Parallel merge: split into two halves and merge
    sgf::WelfordEstimator w1, w2;
    for (int i = 0; i < 4; ++i) w1.observe(data[i]);
    for (int i = 4; i < 8; ++i) w2.observe(data[i]);
    w1.merge(w2);
    auto rm = w1.readout();
    EXPECT_NEAR(rm.mean,     5.0, 1e-9);
    EXPECT_NEAR(rm.variance, 4.571428571, 1e-6);

    printf("  mean=%.4f var=%.4f std=%.4f  PASS\n", r.mean, r.variance, r.std_dev);
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. Online softmax
// ─────────────────────────────────────────────────────────────────────────────
void test_online_softmax() {
    SECTION("Online softmax");

    // Reference: manually computed softmax of [1, 2, 3]
    float logits[3] = {1.0f, 2.0f, 3.0f};
    float Z = std::exp(1.0f) + std::exp(2.0f) + std::exp(3.0f);
    float expected[3] = {
        std::exp(1.0f) / Z,
        std::exp(2.0f) / Z,
        std::exp(3.0f) / Z
    };

    sgf::OnlineSoftmaxState smx;
    for (int i = 0; i < 3; ++i) smx.update(logits[i]);

    for (int i = 0; i < 3; ++i) {
        float got = smx.softmax_val(logits[i]);
        EXPECT_NEAR(got, expected[i], 1e-5f);
    }
    printf("  softmax([1,2,3]) = [%.4f, %.4f, %.4f]  PASS\n",
           smx.softmax_val(1.0f), smx.softmax_val(2.0f), smx.softmax_val(3.0f));

    // Test log-sum-exp
    float lse_expected = std::log(Z);
    EXPECT_NEAR(smx.log_sum_exp(), lse_expected, 1e-5f);

    // Test merge of two states
    sgf::OnlineSoftmaxState s1, s2;
    s1.update(1.0f); s1.update(2.0f);
    s2.update(3.0f);
    auto merged = sgf::OnlineSoftmaxState::merge(s1, s2);
    EXPECT_NEAR(merged.running_max, smx.running_max, 1e-5f);
    EXPECT_NEAR(merged.running_sum, smx.running_sum, 1e-4f);
    printf("  merge test: running_sum=%.4f expected=%.4f  PASS\n",
           merged.running_sum, smx.running_sum);
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. Newton-Schulz / Muon
// ─────────────────────────────────────────────────────────────────────────────
void test_muon() {
    SECTION("Newton-Schulz orthogonalisation");

    // Test: after Newton-Schulz, X X^T should be close to identity (for square matrix)
    const int N = 4;
    std::vector<float> X = {
        1.0f, 0.5f, 0.1f, 0.0f,
        0.3f, 1.0f, 0.2f, 0.1f,
        0.1f, 0.0f, 1.0f, 0.4f,
        0.0f, 0.2f, 0.3f, 1.0f
    };

    sgf::newton_schulz_cpu(X.data(), N, N, 20, 1e-7f);

    // Check X X^T ≈ I
    float max_off_diag = 0.0f;
    float min_diag     = 1e9f;
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            float dot = 0.0f;
            for (int k = 0; k < N; ++k)
                dot += X[i * N + k] * X[j * N + k];
            if (i == j) {
                min_diag = std::min(min_diag, dot);
                EXPECT_NEAR(dot, 1.0f, 0.05f);  // diagonal ≈ 1
            } else {
                max_off_diag = std::max(max_off_diag, std::abs(dot));
                EXPECT_NEAR(dot, 0.0f, 0.05f);  // off-diagonal ≈ 0
            }
        }
    }
    printf("  XX^T: min_diag=%.4f max_off_diag=%.4f  PASS\n",
           min_diag, max_off_diag);
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. ZClip
// ─────────────────────────────────────────────────────────────────────────────
void test_zclip() {
    SECTION("ZClip adaptive gradient clipping");

    sgf::ZClipState zclip;
    zclip.k           = 3.0f;
    zclip.warmup_min  = 10;

    // Feed 20 normal norms (mean≈1, std≈0.1)
    std::mt19937 rng(42);
    std::normal_distribution<float> normal(1.0f, 0.1f);
    for (int i = 0; i < 20; ++i)
        zclip.observe_and_check(normal(rng));

    float mu    = static_cast<float>(zclip.norm_stats.mean);
    float sigma = static_cast<float>(zclip.norm_stats.std_dev());
    float thresh = zclip.threshold();

    EXPECT_NEAR(mu,     1.0f, 0.1f);
    EXPECT_NEAR(sigma,  0.1f, 0.05f);
    EXPECT_NEAR(thresh, mu + 3.0f * sigma, 1e-4f);
    printf("  mean=%.4f sigma=%.4f threshold=%.4f\n", mu, sigma, thresh);

    // Large gradient should trigger clip
    bool clipped = zclip.observe_and_check(5.0f);  // >> mean + 3*sigma
    EXPECT_TRUE(clipped);
    printf("  spike norm=5.0 clipped=%s  PASS\n", clipped ? "YES" : "NO");

    // Normal gradient should NOT clip
    bool not_clipped = !zclip.observe_and_check(1.02f);
    EXPECT_TRUE(not_clipped);
    printf("  normal norm=1.02 not_clipped=%s  PASS\n", not_clipped ? "YES" : "NO");

    // AGC test
    float W[6] = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f}; // 2 rows x 3 cols, norm=sqrt(3)
    float G[6] = {10.f, 10.f, 10.f, 0.1f, 0.1f, 0.1f};  // row 0 has huge norm
    sgf::agc_apply_cpu(G, W, 2, 3, 0.01f);
    float gnorm0 = std::sqrt(G[0]*G[0] + G[1]*G[1] + G[2]*G[2]);
    float wnorm0 = std::sqrt(3.0f);
    EXPECT_NEAR(gnorm0, 0.01f * wnorm0, 1e-4f);
    printf("  AGC: clipped row0 grad_norm=%.5f  PASS\n", gnorm0);
}

// ─────────────────────────────────────────────────────────────────────────────
// 5. WSD Schedule
// ─────────────────────────────────────────────────────────────────────────────
void test_wsd() {
    SECTION("WSD learning rate schedule");

    sgf::WSDConfig cfg;
    cfg.lr_max         = 1e-3f;
    cfg.lr_min         = 1e-5f;
    cfg.warmup_steps   = 10;
    cfg.stable_steps   = 20;
    cfg.cooldown_steps = 10;
    cfg.cooldown       = sgf::CooldownShape::COSINE;

    sgf::WSDScheduler sched(cfg);

    // Warmup: first step should be > lr_min
    float lr0 = sched.step();
    EXPECT_TRUE(lr0 > cfg.lr_min && lr0 < cfg.lr_max);
    printf("  step 1 (warmup): lr=%.2e\n", lr0);

    // After warmup_steps, should be at lr_max
    for (int i = 1; i < 10; ++i) sched.step();
    float lr_stable = sched.step();
    EXPECT_NEAR(lr_stable, cfg.lr_max, 1e-6f);
    EXPECT_TRUE(sched.phase() == sgf::TrainingPhase::STABLE);
    printf("  step 11 (stable): lr=%.2e phase=%s\n",
           lr_stable, sgf::phase_name(sched.phase()));

    // After stable_steps, should enter cooldown
    for (int i = 0; i < 19; ++i) sched.step();
    EXPECT_TRUE(sched.phase() == sgf::TrainingPhase::COOLDOWN);
    printf("  step 31 (cooldown): phase=%s\n", sgf::phase_name(sched.phase()));

    // At end of cooldown, should be near lr_min
    for (int i = 0; i < 10; ++i) sched.step();
    float lr_end = sched.current_lr();
    EXPECT_NEAR(lr_end, cfg.lr_min, 1e-6f);
    printf("  step 41 (done): lr=%.2e  PASS\n", lr_end);

    // Test fork
    sgf::WSDConfig cfg2 = cfg;
    cfg2.stable_steps = 100;
    sgf::WSDScheduler sched2(cfg2);
    for (int i = 0; i < 15; ++i) sched2.step();
    EXPECT_TRUE(sched2.phase() == sgf::TrainingPhase::STABLE);
    auto fork = sched2.fork_cooldown();
    EXPECT_TRUE(fork.phase() == sgf::TrainingPhase::COOLDOWN);
    printf("  fork from stable: fork_phase=%s  PASS\n", sgf::phase_name(fork.phase()));
}

// ─────────────────────────────────────────────────────────────────────────────
// 6. Checkpoint manager
// ─────────────────────────────────────────────────────────────────────────────
void test_checkpoint() {
    SECTION("Roofline-guided checkpoint manager");

    std::vector<sgf::LayerProfile> layers;
    for (int i = 0; i < 16; ++i) {
        sgf::CheckpointPolicy pol;
        if (i % 4 == 0)      pol = sgf::CheckpointPolicy::MUST_STORE;    // residual
        else if (i % 4 == 1) pol = sgf::CheckpointPolicy::MUST_RECOMPUTE;// elementwise
        else                  pol = sgf::CheckpointPolicy::AUTO_SQRT;

        layers.push_back({
            "layer" + std::to_string(i),
            static_cast<uint64_t>(1e9),   // 1G FLOPs (compute-bound)
            static_cast<uint64_t>(10e6),  // 10MB activations
            pol
        });
    }

    sgf::CheckpointManager mgr(200.0);
    mgr.register_layers(layers);

    // MUST_STORE layers should always be stored
    for (int i = 0; i < 16; i += 4) {
        EXPECT_TRUE(mgr.decision(i).should_store);
    }
    // MUST_RECOMPUTE layers should never be stored
    for (int i = 1; i < 16; i += 4) {
        EXPECT_TRUE(!mgr.decision(i).should_store);
    }

    printf("  stored=%d recomputed=%d peak_mem=%.1fMB\n",
           mgr.n_stored(),
           mgr.n_recomputed(),
           static_cast<float>(mgr.peak_activation_bytes()) / 1e6f);

    // EoS-adaptive: progressive sharpening should increase density
    mgr.adapt_to_regime(sgf::SharpnessRegime::PROGRESSIVE_SHARPENING);
    int dense_stored = mgr.n_stored();
    mgr.adapt_to_regime(sgf::SharpnessRegime::CONVERGING);
    int sparse_stored = mgr.n_stored();
    EXPECT_TRUE(dense_stored >= sparse_stored);
    printf("  progressive_sharpening stored=%d converging stored=%d  PASS\n",
           dense_stored, sparse_stored);
}

// ─────────────────────────────────────────────────────────────────────────────
// 7. MoE router
// ─────────────────────────────────────────────────────────────────────────────
void test_moe() {
    SECTION("MoE router + load balancing");

    sgf::MoEConfig cfg;
    cfg.n_experts = 4;
    cfg.top_k     = 2;
    cfg.router    = sgf::RouterType::TOP_K;

    sgf::MoERouter router(cfg);

    // 8 tokens, 4 experts
    float logits[8 * 4] = {
        1.0f, 2.0f, 0.5f, 0.1f,   // token 0 → experts 1, 0
        0.1f, 0.5f, 2.0f, 1.0f,   // token 1 → experts 2, 3
        2.5f, 1.0f, 0.2f, 0.3f,   // token 2 → experts 0, 1
        0.3f, 0.2f, 1.0f, 2.5f,   // token 3 → experts 3, 2
        1.5f, 1.5f, 0.1f, 0.2f,   // token 4 → experts 0/1 (tie)
        0.2f, 0.1f, 1.5f, 1.5f,   // token 5 → experts 2/3 (tie)
        1.0f, 1.0f, 1.0f, 1.0f,   // token 6 → uniform
        2.0f, 0.0f, 0.0f, 0.0f    // token 7 → expert 0 overwhelmingly
    };

    auto routes = router.route(logits, 8);

    // Verify each route has top_k selected
    for (int t = 0; t < 8; ++t) {
        EXPECT_TRUE(routes[t].n_selected == 2);
        // Weights should sum to ~1
        float wsum = 0.0f;
        for (int k = 0; k < routes[t].n_selected; ++k)
            wsum += routes[t].expert_weights[k];
        EXPECT_NEAR(wsum, 1.0f, 1e-5f);
    }

    printf("  token 0: experts=[%d,%d] weights=[%.3f,%.3f]\n",
           routes[0].expert_ids[0], routes[0].expert_ids[1],
           routes[0].expert_weights[0], routes[0].expert_weights[1]);

    // aux_loss should be positive
    float aux = router.aux_loss();
    EXPECT_TRUE(aux >= 0.0f);
    printf("  aux_loss=%.4f  PASS\n", aux);

    // Test expert-choice routing
    cfg.router = sgf::RouterType::EXPERT_CHOICE;
    sgf::MoERouter ec_router(cfg);
    auto ec_routes = ec_router.route(logits, 8);
    printf("  ExpertChoice: token 0 selected=%d experts\n", ec_routes[0].n_selected);
}

// ─────────────────────────────────────────────────────────────────────────────
// 8. Speculative decoding
// ─────────────────────────────────────────────────────────────────────────────
void test_speculative() {
    SECTION("Speculative decoding controller");

    const int V = 16; // tiny vocab

    // Perfect draft (identical to target) → acceptance rate = 1.0
    auto make_uniform = [&]() {
        sgf::TokenDist d(V);
        for (int i = 0; i < V; ++i) d[i] = 1.0f / V;
        return d;
    };

    auto draft_fn = [&](const sgf::SpeculativeDecoder::Context&) {
        return make_uniform();
    };

    // Target = same uniform distribution → p/q = 1 for all tokens → always accept
    auto target_fn = [&](const sgf::SpeculativeDecoder::Context& ctx,
                          const std::vector<int>& draft_tokens)
        -> std::vector<sgf::TokenDist>
    {
        std::vector<sgf::TokenDist> out(draft_tokens.size() + 1, sgf::TokenDist(V));
        for (auto& d : out)
            for (int i = 0; i < V; ++i) d[i] = 1.0f / V;
        return out;
    };

    sgf::SpeculativeDecoder::Config cfg;
    cfg.k = 4;
    cfg.rng_seed = 7;

    sgf::SpeculativeDecoder decoder(draft_fn, target_fn, cfg);

    sgf::SpeculativeDecoder::Context ctx = {1, 2, 3};
    int total_accepted = 0;
    for (int trial = 0; trial < 50; ++trial) {
        auto result = decoder.step(ctx);
        total_accepted += result.n_accepted;
        // With uniform p=q, should always accept all k draft tokens
        EXPECT_TRUE(result.accepted_tokens.size() >= 1);
    }

    double mean_accept = decoder.mean_acceptance_rate();
    // With p=q=uniform, acceptance prob = min(1, 1) = 1 → perfect acceptance
    EXPECT_NEAR(mean_accept, 1.0, 0.05);
    printf("  mean_acceptance_rate=%.4f (expected ~1.0)  PASS\n", mean_accept);

    float speedup = decoder.throughput_multiplier(10.0f);
    EXPECT_TRUE(speedup > 1.0f);
    printf("  throughput_multiplier=%.2f  PASS\n", speedup);
}

// ─────────────────────────────────────────────────────────────────────────────
// 9. QQT data quality tracker
// ─────────────────────────────────────────────────────────────────────────────
void test_qqt() {
    SECTION("QQT data quality tracker");

    sgf::QQTConfig cfg;
    cfg.gamma            = 0.7f;
    cfg.rep_penalty_lam  = 1.0f;
    cfg.filter_threshold = 0.05f;

    sgf::DataQualityTracker tracker(cfg);

    // High quality, seen once → high utility
    tracker.record_observation(1, 1.0f);
    float u1 = tracker.marginal_utility(1);
    EXPECT_NEAR(u1, std::pow(1.0f, 0.7f) / (1.0f + 1.0f), 1e-5f);

    // Same sample seen 10x → utility should drop
    for (int i = 0; i < 9; ++i) tracker.record_observation(1, 1.0f);
    float u1_repeated = tracker.marginal_utility(1);
    EXPECT_TRUE(u1_repeated < u1);
    printf("  first_seen_util=%.4f repeated_10x_util=%.4f\n", u1, u1_repeated);

    // Low quality sample
    tracker.record_observation(2, 0.1f);
    float u2 = tracker.marginal_utility(2);
    EXPECT_TRUE(u2 < u1);
    printf("  low_quality(0.1) util=%.4f  PASS\n", u2);

    // Unseen sample → max utility (1.0)
    EXPECT_NEAR(tracker.marginal_utility(999), 1.0f, 1e-5f);
    printf("  unseen sample util=1.0  PASS\n");
}

// ─────────────────────────────────────────────────────────────────────────────
// 10. Full SGF orchestrator integration
// ─────────────────────────────────────────────────────────────────────────────
void test_sgf_orchestrator() {
    SECTION("SGF Orchestrator integration step");

    // Tiny 2-layer model config
    sgf::SGFConfig cfg;
    cfg.wsd.lr_max       = 1e-3f;
    cfg.wsd.lr_min       = 1e-5f;
    cfg.wsd.warmup_steps = 5;
    cfg.wsd.stable_steps = 10;
    cfg.wsd.cooldown_steps = 5;

    // One weight matrix + one embedding
    cfg.param_groups.push_back({"W1", 4, 4, sgf::OptimizerType::MUON, 1.0f, true});
    cfg.param_groups.push_back({"embed", 1, 4, sgf::OptimizerType::ADAM, 1.0f, false});

    sgf::SGFOrchestrator orch(cfg);

    // Initialise weights and gradients
    std::vector<float> W1(16, 0.1f), W1_grad(16, 0.01f);
    std::vector<float> emb(4, 0.5f), emb_grad(4, 0.001f);

    std::unordered_map<std::string, float*> grads   = {{"W1", W1_grad.data()},
                                                        {"embed", emb_grad.data()}};
    std::unordered_map<std::string, float*> weights = {{"W1", W1.data()},
                                                        {"embed", emb.data()}};

    // Run 25 steps
    sgf::SGFStepReport last_report{};
    for (int i = 0; i < 25; ++i) {
        // Refresh grads each step
        for (auto& v : W1_grad) v = 0.01f;
        for (auto& v : emb_grad) v = 0.001f;
        last_report = orch.step(grads, weights);
    }

    printf("  final step=%lu phase=%s lr=%.2e grad_norm=%.4f\n",
           (unsigned long)last_report.global_step,
           sgf::phase_name(last_report.phase),
           static_cast<double>(last_report.learning_rate),
           static_cast<double>(last_report.grad_norm));

    EXPECT_TRUE(last_report.global_step == 25);
    EXPECT_TRUE(last_report.phase == sgf::TrainingPhase::DONE ||
                last_report.phase == sgf::TrainingPhase::COOLDOWN);

    // Weights should have changed from initial values
    bool weights_changed = false;
    for (float v : W1) if (std::abs(v - 0.1f) > 1e-7f) { weights_changed = true; break; }
    EXPECT_TRUE(weights_changed);
    printf("  weights updated: W1[0]=%.6f (initial=0.1)  PASS\n", W1[0]);
}

// ─────────────────────────────────────────────────────────────────────────────
// Main
// ─────────────────────────────────────────────────────────────────────────────
int main() {
    printf("════════════════════════════════════════\n");
    printf("  Streaming Geometry Framework — Tests  \n");
    printf("════════════════════════════════════════\n");

    test_welford();
    test_online_softmax();
    test_muon();
    test_zclip();
    test_wsd();
    test_checkpoint();
    test_moe();
    test_speculative();
    test_qqt();
    test_sgf_orchestrator();

    printf("\n════════════════════════════════════════\n");
    printf("  RESULTS: %d passed, %d failed\n", g_pass, g_fail);
    printf("════════════════════════════════════════\n");

    return (g_fail == 0) ? 0 : 1;
}
