/**
 * bench_gpu.cu — GPU micro-benchmarks for SGF kernels
 * Compile: nvcc -std=c++17 -O3 -I../include -lcublas -lcusolver bench_gpu.cu -o bench_gpu
 */
#include <cuda_runtime.h>
#include <cublas_v2.h>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include "sgf/sgf.h"

#define N_WARMUP  10
#define N_ITERS   100

double elapsed_ms(cudaEvent_t start, cudaEvent_t stop) {
    float ms;
    cudaEventElapsedTime(&ms, start, stop);
    return ms;
}

void bench_welford(int n = 1 << 22) {
    float *d_in, *d_out;
    SGF_CUDA_CHECK(cudaMalloc(&d_in,  n * sizeof(float)));
    SGF_CUDA_CHECK(cudaMalloc(&d_out, 3 * sizeof(float)));
    cudaMemset(d_in, 0, n * sizeof(float));

    cudaEvent_t s, e;
    cudaEventCreate(&s); cudaEventCreate(&e);

    for (int i = 0; i < N_WARMUP; ++i)
        sgf::launch_welford(d_in, d_out, n);
    cudaDeviceSynchronize();

    cudaEventRecord(s);
    for (int i = 0; i < N_ITERS; ++i)
        sgf::launch_welford(d_in, d_out, n);
    cudaEventRecord(e);
    cudaEventSynchronize(e);

    double ms = elapsed_ms(s, e) / N_ITERS;
    double bw = static_cast<double>(n) * sizeof(float) / (ms * 1e6);
    printf("[Welford]     n=%7.1fM   %.3f ms   %.1f GB/s\n",
           n / 1e6, ms, bw);

    cudaFree(d_in); cudaFree(d_out);
}

void bench_layernorm(int rows = 4096, int cols = 4096) {
    float *d_in, *d_out;
    SGF_CUDA_CHECK(cudaMalloc(&d_in,  (size_t)rows * cols * sizeof(float)));
    SGF_CUDA_CHECK(cudaMalloc(&d_out, (size_t)rows * cols * sizeof(float)));
    cudaMemset(d_in, 0, (size_t)rows * cols * sizeof(float));

    cudaEvent_t s, e;
    cudaEventCreate(&s); cudaEventCreate(&e);

    for (int i = 0; i < N_WARMUP; ++i)
        sgf::launch_layernorm(d_in, d_out, nullptr, nullptr, rows, cols);
    cudaDeviceSynchronize();

    cudaEventRecord(s);
    for (int i = 0; i < N_ITERS; ++i)
        sgf::launch_layernorm(d_in, d_out, nullptr, nullptr, rows, cols);
    cudaEventRecord(e);
    cudaEventSynchronize(e);

    double ms = elapsed_ms(s, e) / N_ITERS;
    double bytes = 2.0 * rows * cols * sizeof(float);
    double bw = bytes / (ms * 1e6);
    printf("[LayerNorm]   %dx%d   %.3f ms   %.1f GB/s\n", rows, cols, ms, bw);

    cudaFree(d_in); cudaFree(d_out);
}

void bench_softmax(int rows = 4096, int cols = 32000) {
    float *d_in, *d_out;
    SGF_CUDA_CHECK(cudaMalloc(&d_in,  (size_t)rows * cols * sizeof(float)));
    SGF_CUDA_CHECK(cudaMalloc(&d_out, (size_t)rows * cols * sizeof(float)));
    cudaMemset(d_in, 0, (size_t)rows * cols * sizeof(float));

    cudaEvent_t s, e;
    cudaEventCreate(&s); cudaEventCreate(&e);

    for (int i = 0; i < N_WARMUP; ++i)
        sgf::launch_softmax(d_in, d_out, rows, cols);
    cudaDeviceSynchronize();

    cudaEventRecord(s);
    for (int i = 0; i < N_ITERS; ++i)
        sgf::launch_softmax(d_in, d_out, rows, cols);
    cudaEventRecord(e);
    cudaEventSynchronize(e);

    double ms = elapsed_ms(s, e) / N_ITERS;
    double bytes = 2.0 * rows * cols * sizeof(float);
    double bw = bytes / (ms * 1e6);
    printf("[Softmax]     %dx%d   %.3f ms   %.1f GB/s\n", rows, cols, ms, bw);

    cudaFree(d_in); cudaFree(d_out);
}

void bench_moe_routing(int n_tokens = 8192, int n_experts = 256) {
    float *d_logits;
    int   *d_ids;
    float *d_weights;
    int   top_k = 2;
    SGF_CUDA_CHECK(cudaMalloc(&d_logits,  (size_t)n_tokens * n_experts * sizeof(float)));
    SGF_CUDA_CHECK(cudaMalloc(&d_ids,     (size_t)n_tokens * top_k     * sizeof(int)));
    SGF_CUDA_CHECK(cudaMalloc(&d_weights, (size_t)n_tokens * top_k     * sizeof(float)));
    cudaMemset(d_logits, 0, (size_t)n_tokens * n_experts * sizeof(float));

    cudaEvent_t s, e;
    cudaEventCreate(&s); cudaEventCreate(&e);

    // top_k=2, n_experts=256
    for (int i = 0; i < N_WARMUP; ++i)
        sgf::launch_moe_topk<2, 256>(d_logits, d_ids, d_weights, n_tokens);
    cudaDeviceSynchronize();

    cudaEventRecord(s);
    for (int i = 0; i < N_ITERS; ++i)
        sgf::launch_moe_topk<2, 256>(d_logits, d_ids, d_weights, n_tokens);
    cudaEventRecord(e);
    cudaEventSynchronize(e);

    double ms = elapsed_ms(s, e) / N_ITERS;
    printf("[MoE top-k]   tokens=%d experts=%d top_k=%d   %.3f ms\n",
           n_tokens, n_experts, top_k, ms);

    cudaFree(d_logits); cudaFree(d_ids); cudaFree(d_weights);
}

int main() {
    printf("══════════════════════════════════════════\n");
    printf("   SGF GPU Micro-Benchmarks               \n");
    printf("══════════════════════════════════════════\n");

    int device;
    cudaGetDevice(&device);
    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, device);
    printf("Device: %s  (%.0f GB HBM)\n\n",
           prop.name, prop.totalGlobalMem / 1e9);

    bench_welford();
    bench_layernorm();
    bench_softmax();
    bench_moe_routing();

    printf("\nAll benchmarks complete.\n");
    return 0;
}
