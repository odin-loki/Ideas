#pragma once
/**
 * sgf/checkpoint.h — Roofline-guided gradient checkpointing memory manager
 *
 * IRE instance:
 *   M    = Activation space (per-layer tensors)
 *   S    = Checkpoint set C ⊆ {layer activations} of size O(sqrt(n))
 *   T    = Keep/discard decision per layer based on roofline policy
 *   phi  = Recompute from nearest saved checkpoint during backward pass
 *
 * Roofline decision rule:
 *   For each layer l with arithmetic intensity I_l = FLOPs_l / bytes_l:
 *     if I_l < ridge_point  → memory-bound → recompute preferred (RECOMPUTE)
 *     if I_l >= ridge_point → compute-bound → store preferred (STORE)
 *
 * Predefined layer classes:
 *   MUST_STORE    : residual connections, matmul outputs (high recompute cost)
 *   MUST_RECOMPUTE: elementwise ops — GeLU, ReLU, dropout (trivially cheap)
 *   ROOFLINE      : decided by I_l vs ridge_point
 *
 * EoS-Adaptive extension (Prediction 3):
 *   During PROGRESSIVE_SHARPENING phase: dense checkpointing (every sqrt(n/2))
 *   During EDGE_OF_STABILITY:            standard (every sqrt(n))
 *   During CONVERGING:                   sparse (every sqrt(2n))
 */

#include "ire.h"
#include "wsd.h"    // for SharpnessRegime
#include <vector>
#include <cstdint>
#include <cstring>
#include <cassert>
#include <functional>
#include <unordered_map>
#include <cmath>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Layer descriptor
// ─────────────────────────────────────────────────────────────────────────────
enum class CheckpointPolicy {
    MUST_STORE,       // Always save (residual, attention output)
    MUST_RECOMPUTE,   // Always recompute (elementwise, cheap)
    ROOFLINE,         // Decide by I_l vs ridge_point
    AUTO_SQRT         // Place every sqrt(n) layers automatically
};

struct LayerProfile {
    std::string    name;
    uint64_t       flops;           // estimated FLOPs for forward pass
    uint64_t       activation_bytes;// bytes of activation tensor to save
    CheckpointPolicy policy;

    double arithmetic_intensity() const {
        return activation_bytes > 0
            ? static_cast<double>(flops) / static_cast<double>(activation_bytes)
            : 0.0;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// Checkpoint schedule result for one layer
// ─────────────────────────────────────────────────────────────────────────────
struct CheckpointDecision {
    bool should_store;     // true = save activation; false = recompute during backward
    int  recompute_from;   // if should_store=false, nearest predecessor to recompute from
};

// ─────────────────────────────────────────────────────────────────────────────
// Checkpointing Memory Manager (host-side)
// ─────────────────────────────────────────────────────────────────────────────
class CheckpointManager {
public:
    explicit CheckpointManager(double ridge_point_flop_per_byte = 200.0)
        : ridge_(ridge_point_flop_per_byte) {}

    /// Register all layers of the model in forward-pass order
    void register_layers(const std::vector<LayerProfile>& layers) {
        layers_ = layers;
        recompute_schedule();
    }

    /// Query decision for layer i (0-indexed)
    CheckpointDecision decision(int layer_idx) const {
        assert(layer_idx >= 0 && layer_idx < (int)schedule_.size());
        return schedule_[layer_idx];
    }

    /// Update ridge point (e.g., if switching hardware) and reschedule
    void set_ridge_point(double ridge) {
        ridge_ = ridge;
        recompute_schedule();
    }

    /// EoS-adaptive: update spacing based on current sharpness regime
    void adapt_to_regime(SharpnessRegime regime) {
        switch (regime) {
            case SharpnessRegime::PROGRESSIVE_SHARPENING:
                spacing_multiplier_ = 0.5f; break;  // 2x denser
            case SharpnessRegime::EDGE_OF_STABILITY:
                spacing_multiplier_ = 1.0f; break;  // standard
            case SharpnessRegime::CONVERGING:
                spacing_multiplier_ = 2.0f; break;  // 2x sparser
        }
        recompute_schedule();
    }

    int  n_stored()     const { return n_stored_; }
    int  n_recomputed() const { return (int)layers_.size() - n_stored_; }

    /// Peak memory estimate (bytes) for the current schedule
    uint64_t peak_activation_bytes() const {
        uint64_t total = 0;
        for (int i = 0; i < (int)layers_.size(); ++i)
            if (schedule_[i].should_store)
                total += layers_[i].activation_bytes;
        return total;
    }

    /// Recompute FLOPs overhead estimate
    uint64_t recompute_flops() const {
        uint64_t total = 0;
        for (int i = 0; i < (int)layers_.size(); ++i)
            if (!schedule_[i].should_store)
                total += layers_[i].flops;
        return total;
    }

private:
    void recompute_schedule() {
        int n = static_cast<int>(layers_.size());
        schedule_.resize(n);
        n_stored_ = 0;

        // Step 1: apply explicit policies
        std::vector<bool> forced_store(n, false);
        std::vector<bool> forced_recompute(n, false);
        for (int i = 0; i < n; ++i) {
            switch (layers_[i].policy) {
                case CheckpointPolicy::MUST_STORE:
                    forced_store[i] = true; break;
                case CheckpointPolicy::MUST_RECOMPUTE:
                    forced_recompute[i] = true; break;
                default: break;
            }
        }

        // Step 2: AUTO_SQRT and ROOFLINE decisions
        // Count undecided layers for sqrt spacing
        int undecided = 0;
        for (int i = 0; i < n; ++i)
            if (!forced_store[i] && !forced_recompute[i]) ++undecided;

        int spacing = std::max(1,
            static_cast<int>(std::sqrt(static_cast<double>(undecided)) *
                             spacing_multiplier_));

        int undecided_count = 0;
        for (int i = 0; i < n; ++i) {
            if (forced_store[i]) {
                schedule_[i].should_store  = true;
            } else if (forced_recompute[i]) {
                schedule_[i].should_store  = false;
            } else {
                bool store = false;
                if (layers_[i].policy == CheckpointPolicy::ROOFLINE) {
                    store = (layers_[i].arithmetic_intensity() >= ridge_);
                } else {
                    // AUTO_SQRT: keep every `spacing`-th undecided layer
                    store = (undecided_count % spacing == 0);
                }
                ++undecided_count;
                schedule_[i].should_store = store;
            }

            if (schedule_[i].should_store) {
                ++n_stored_;
                schedule_[i].recompute_from = i;
            } else {
                // Find nearest preceding stored layer
                schedule_[i].recompute_from = -1;
                for (int j = i - 1; j >= 0; --j) {
                    if (schedule_[j].should_store) {
                        schedule_[i].recompute_from = j;
                        break;
                    }
                }
            }
        }
    }

    std::vector<LayerProfile>       layers_;
    std::vector<CheckpointDecision> schedule_;
    double ridge_             = 200.0; // H100: ~60 FLOP/byte; A100: ~200
    float  spacing_multiplier_ = 1.0f;
    int    n_stored_           = 0;
};

// ─────────────────────────────────────────────────────────────────────────────
// Runtime activation store: manages saved tensors during forward pass
// Works with arbitrary byte blobs — no CUDA required for the manager itself.
// ─────────────────────────────────────────────────────────────────────────────
struct ActivationBlob {
    std::vector<uint8_t> data;
    std::vector<int64_t> shape;
    std::string          dtype;  // "fp32", "bf16", "fp16"
};

class ActivationStore {
public:
    void save(int layer_idx, ActivationBlob blob) {
        store_[layer_idx] = std::move(blob);
    }

    const ActivationBlob* get(int layer_idx) const {
        auto it = store_.find(layer_idx);
        return it != store_.end() ? &it->second : nullptr;
    }

    void release(int layer_idx) {
        store_.erase(layer_idx);
    }

    void clear() { store_.clear(); }

    uint64_t total_bytes() const {
        uint64_t total = 0;
        for (auto& [k, v] : store_) total += v.data.size();
        return total;
    }

private:
    std::unordered_map<int, ActivationBlob> store_;
};

#ifdef __CUDACC__
// ─────────────────────────────────────────────────────────────────────────────
// GPU activation store: saves/restores device tensors by layer index
// Uses pinned host memory for fast H2D/D2H transfers
// ─────────────────────────────────────────────────────────────────────────────
class GPUActivationStore {
    struct Entry {
        float*   d_data   = nullptr;
        float*   h_pinned = nullptr;
        size_t   n_bytes  = 0;
        bool     on_device = false;
    };

public:
    ~GPUActivationStore() { clear(); }

    void save_device(int layer_idx, const float* d_src, size_t n_bytes,
                     cudaStream_t stream = nullptr)
    {
        release(layer_idx);
        Entry e;
        e.n_bytes = n_bytes;
        SGF_CUDA_CHECK(cudaMalloc(&e.d_data, n_bytes));
        SGF_CUDA_CHECK(cudaMemcpyAsync(e.d_data, d_src, n_bytes,
                                        cudaMemcpyDeviceToDevice, stream));
        e.on_device = true;
        entries_[layer_idx] = e;
    }

    /// Offload to pinned host memory (frees GPU memory)
    void offload_to_host(int layer_idx, cudaStream_t stream = nullptr) {
        auto it = entries_.find(layer_idx);
        if (it == entries_.end() || !it->second.on_device) return;
        Entry& e = it->second;
        SGF_CUDA_CHECK(cudaMallocHost(&e.h_pinned, e.n_bytes));
        SGF_CUDA_CHECK(cudaMemcpyAsync(e.h_pinned, e.d_data, e.n_bytes,
                                        cudaMemcpyDeviceToHost, stream));
        SGF_CUDA_CHECK(cudaStreamSynchronize(stream));
        cudaFree(e.d_data);
        e.d_data   = nullptr;
        e.on_device = false;
    }

    /// Restore from host to device
    float* restore_to_device(int layer_idx, cudaStream_t stream = nullptr) {
        auto it = entries_.find(layer_idx);
        if (it == entries_.end()) return nullptr;
        Entry& e = it->second;
        if (!e.on_device) {
            SGF_CUDA_CHECK(cudaMalloc(&e.d_data, e.n_bytes));
            SGF_CUDA_CHECK(cudaMemcpyAsync(e.d_data, e.h_pinned, e.n_bytes,
                                            cudaMemcpyHostToDevice, stream));
            e.on_device = true;
        }
        return e.d_data;
    }

    void release(int layer_idx) {
        auto it = entries_.find(layer_idx);
        if (it == entries_.end()) return;
        if (it->second.d_data)   cudaFree(it->second.d_data);
        if (it->second.h_pinned) cudaFreeHost(it->second.h_pinned);
        entries_.erase(it);
    }

    void clear() {
        for (auto& [k, e] : entries_) {
            if (e.d_data)   cudaFree(e.d_data);
            if (e.h_pinned) cudaFreeHost(e.h_pinned);
        }
        entries_.clear();
    }

    size_t device_bytes_used() const {
        size_t total = 0;
        for (auto& [k, e] : entries_)
            if (e.on_device) total += e.n_bytes;
        return total;
    }

private:
    std::unordered_map<int, Entry> entries_;
};
#endif // __CUDACC__

} // namespace sgf
