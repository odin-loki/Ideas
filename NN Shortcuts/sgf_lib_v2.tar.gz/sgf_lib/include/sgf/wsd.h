#pragma once
/**
 * sgf/wsd.h — Warmup-Stable-Decay (WSD) learning rate schedule
 *
 * IRE instance:
 *   M    = R^+  (learning rate space)
 *   S    = (step_count, phase, phase_start_step)  — three integers
 *   T    = increment step, evaluate phase transition
 *   phi  = lr(S)  — read-out the current learning rate
 *
 * Three phases:
 *   WARMUP  : linear ramp from 0 to lr_max over warmup_steps
 *   STABLE  : constant lr_max  (the bulk of training)
 *   COOLDOWN: cosine or linear decay from lr_max to lr_min
 *
 * Integration with ZClip (SGF Prediction 2):
 *   When ZClipState enters "stable low-trigger" regime
 *   (clip_rate < trigger_threshold for window_steps consecutive steps),
 *   the schedule can auto-trigger cooldown without a manually set budget.
 *
 * Multiple stable-phase checkpoints can be forked; cooldown is cheap post-processing
 * (~1% of total training tokens in practice).
 */

#include "ire.h"
#include "zclip.cuh"
#include <cmath>
#include <cstdint>
#include <cassert>
#include <string>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Training phase tags
// ─────────────────────────────────────────────────────────────────────────────
enum class TrainingPhase : uint8_t {
    WARMUP   = 0,
    STABLE   = 1,
    COOLDOWN = 2,
    DONE     = 3
};

inline const char* phase_name(TrainingPhase p) {
    switch (p) {
        case TrainingPhase::WARMUP:   return "WARMUP";
        case TrainingPhase::STABLE:   return "STABLE";
        case TrainingPhase::COOLDOWN: return "COOLDOWN";
        case TrainingPhase::DONE:     return "DONE";
        default:                      return "UNKNOWN";
    }
}

enum class CooldownShape : uint8_t {
    COSINE = 0,   // smooth cosine decay
    LINEAR = 1,   // linear decay (simpler, slightly worse in practice)
    SQRT   = 2    // sqrt decay (aggressive early, slow late)
};

// ─────────────────────────────────────────────────────────────────────────────
// WSD State (sufficient statistic)
// ─────────────────────────────────────────────────────────────────────────────
struct WSDState {
    uint64_t step             = 0;
    uint64_t phase_start_step = 0;
    TrainingPhase phase       = TrainingPhase::WARMUP;
};

// ─────────────────────────────────────────────────────────────────────────────
// WSD Config
// ─────────────────────────────────────────────────────────────────────────────
struct WSDConfig {
    float    lr_max          = 3e-4f;
    float    lr_min          = 1e-5f;
    uint64_t warmup_steps    = 500;
    uint64_t stable_steps    = 0;       // 0 = run until manually or auto triggered
    uint64_t cooldown_steps  = 1000;
    CooldownShape cooldown   = CooldownShape::COSINE;

    // ZClip-based auto phase detection (Prediction 2)
    bool     auto_cooldown         = false;
    float    zclip_trigger_rate    = 0.01f;  // trigger if clip_rate drops below this
    uint64_t zclip_window          = 100;    // consecutive steps below threshold
};

// ─────────────────────────────────────────────────────────────────────────────
// WSD Scheduler
// ─────────────────────────────────────────────────────────────────────────────
class WSDScheduler
    : public IREBase<WSDScheduler, WSDState, float, RealLineManifold>
{
public:
    explicit WSDScheduler(WSDConfig cfg = {}) : cfg_(cfg) {}

    // IREBase interface
    void update_impl(int /*unused*/) { advance(); }
    float readout_impl() const { return current_lr(); }
    void merge_impl(const WSDScheduler&) {} // schedules don't merge
    void reset_impl() { state_ = WSDState{}; zclip_low_count_ = 0; }

    /// Advance one step; optionally pass ZClipState for auto-cooldown
    float step(const ZClipState* zclip = nullptr) {
        advance(zclip);
        return current_lr();
    }

    float current_lr() const {
        uint64_t phase_step = state_.step - state_.phase_start_step;
        switch (state_.phase) {
            case TrainingPhase::WARMUP: {
                // Linear ramp: 0 -> lr_max over warmup_steps
                float frac = cfg_.warmup_steps > 0
                    ? static_cast<float>(phase_step) / static_cast<float>(cfg_.warmup_steps)
                    : 1.0f;
                return cfg_.lr_min + frac * (cfg_.lr_max - cfg_.lr_min);
            }
            case TrainingPhase::STABLE:
                return cfg_.lr_max;

            case TrainingPhase::COOLDOWN: {
                float frac = cfg_.cooldown_steps > 0
                    ? std::min(1.0f,
                        static_cast<float>(phase_step) /
                        static_cast<float>(cfg_.cooldown_steps))
                    : 1.0f;
                float decay;
                switch (cfg_.cooldown) {
                    case CooldownShape::COSINE:
                        decay = 0.5f * (1.0f + std::cos(M_PI * frac));
                        break;
                    case CooldownShape::LINEAR:
                        decay = 1.0f - frac;
                        break;
                    case CooldownShape::SQRT:
                        decay = std::sqrt(1.0f - frac);
                        break;
                    default:
                        decay = 0.5f * (1.0f + std::cos(M_PI * frac));
                }
                return cfg_.lr_min + decay * (cfg_.lr_max - cfg_.lr_min);
            }
            case TrainingPhase::DONE:
                return cfg_.lr_min;
        }
        return cfg_.lr_min;
    }

    /// Manually trigger cooldown (e.g., at end of token budget)
    void trigger_cooldown() {
        if (state_.phase == TrainingPhase::STABLE) {
            state_.phase            = TrainingPhase::COOLDOWN;
            state_.phase_start_step = state_.step;
        }
    }

    /// Fork: create a new scheduler from current stable phase checkpoint
    /// The fork starts a cooldown immediately.
    WSDScheduler fork_cooldown(WSDConfig override_cfg = {}) const {
        WSDConfig fork_cfg = (override_cfg.lr_max > 0) ? override_cfg : cfg_;
        WSDScheduler fork(fork_cfg);
        fork.state_ = state_;
        // Force into cooldown phase
        fork.state_.phase            = TrainingPhase::COOLDOWN;
        fork.state_.phase_start_step = state_.step;
        return fork;
    }

    TrainingPhase phase()    const { return state_.phase; }
    uint64_t      total_step() const { return state_.step; }

    const WSDConfig& config() const { return cfg_; }
    const WSDState&  state()  const { return state_; }

private:
    WSDConfig cfg_;
    WSDState  state_;
    uint64_t  zclip_low_count_ = 0;

    void advance(const ZClipState* zclip = nullptr) {
        ++state_.step;
        uint64_t phase_step = state_.step - state_.phase_start_step;

        switch (state_.phase) {
            case TrainingPhase::WARMUP:
                if (phase_step >= cfg_.warmup_steps) {
                    state_.phase            = TrainingPhase::STABLE;
                    state_.phase_start_step = state_.step;
                }
                break;

            case TrainingPhase::STABLE:
                // Check fixed budget
                if (cfg_.stable_steps > 0 && phase_step >= cfg_.stable_steps) {
                    state_.phase            = TrainingPhase::COOLDOWN;
                    state_.phase_start_step = state_.step;
                    break;
                }
                // Check ZClip-based auto trigger
                if (cfg_.auto_cooldown && zclip != nullptr) {
                    if (zclip->clip_rate() < cfg_.zclip_trigger_rate)
                        ++zclip_low_count_;
                    else
                        zclip_low_count_ = 0;

                    if (zclip_low_count_ >= cfg_.zclip_window) {
                        state_.phase            = TrainingPhase::COOLDOWN;
                        state_.phase_start_step = state_.step;
                        zclip_low_count_        = 0;
                    }
                }
                break;

            case TrainingPhase::COOLDOWN:
                if (phase_step >= cfg_.cooldown_steps) {
                    state_.phase            = TrainingPhase::DONE;
                    state_.phase_start_step = state_.step;
                }
                break;

            case TrainingPhase::DONE:
                break;
        }
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// Edge-of-Stability monitor (sharpness tracker for EoS-adaptive checkpointing)
//
// IRE instance:
//   M   = R^+  (Hessian eigenvalue space)
//   S   = (lambda_max_ema, step_count)
//   T   = Power iteration + EMA update
//   phi = (lambda_max, sharpness_regime)
// ─────────────────────────────────────────────────────────────────────────────
enum class SharpnessRegime {
    PROGRESSIVE_SHARPENING,  // lambda_max still rising
    EDGE_OF_STABILITY,       // lambda_max ≈ 2/lr  (oscillating)
    CONVERGING               // lambda_max falling
};

struct EoSMonitor {
    float lambda_max_ema  = 0.0f;
    float lambda_max_prev = 0.0f;
    float ema_beta        = 0.95f;
    uint64_t step         = 0;

    /// Update with a new sharpness estimate (e.g., from power iteration or
    /// Rademacher-vector Hessian-vector product approximation)
    void update(float lambda_estimate) {
        ++step;
        if (step == 1) {
            lambda_max_ema = lambda_estimate;
        } else {
            lambda_max_prev = lambda_max_ema;
            lambda_max_ema  = ema_beta * lambda_max_ema +
                              (1.0f - ema_beta) * lambda_estimate;
        }
    }

    SharpnessRegime regime(float lr) const {
        float eos_threshold = 2.0f / (lr + 1e-9f);
        float delta = lambda_max_ema - lambda_max_prev;
        if (lambda_max_ema < 0.9f * eos_threshold && delta > 0.0f)
            return SharpnessRegime::PROGRESSIVE_SHARPENING;
        if (lambda_max_ema >= 0.9f * eos_threshold)
            return SharpnessRegime::EDGE_OF_STABILITY;
        return SharpnessRegime::CONVERGING;
    }

    /// Recommended checkpoint spacing (EoS-Adaptive Checkpointing, Prediction 3)
    /// Returns a relative density multiplier: >1 means checkpoint more often
    float checkpoint_density(float lr) const {
        switch (regime(lr)) {
            case SharpnessRegime::PROGRESSIVE_SHARPENING: return 2.0f;
            case SharpnessRegime::EDGE_OF_STABILITY:      return 1.0f;
            case SharpnessRegime::CONVERGING:             return 0.5f;
        }
        return 1.0f;
    }
};

} // namespace sgf
