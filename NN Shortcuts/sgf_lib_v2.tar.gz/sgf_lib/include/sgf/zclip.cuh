#pragma once
/**
 * sgf/zclip.cuh — ZClip adaptive gradient clipping (Welford z-score)
 *                 + AGC per-layer weight-relative clipping
 *
 * ZClip IRE instance:
 *   M   = R^+ (gradient norm space)
 *   S   = Welford (n, mean, M2) of gradient norms
 *   T   = Welford update with current ||g||
 *   phi = clip threshold = mean + k * std_dev
 *
 * AGC (Adaptive Gradient Clipping, Brock et al. 2021):
 *   For weight row w_i, clip gradient row g_i if:
 *     ||g_i||_2 > lambda * ||w_i||_2
 *   Unit-wise, eliminates cross-layer spill-over.
 *
 * CRITICAL rule: never apply AGC to embedding/final linear layers.
 */

#include "ire.h"
#include "welford.cuh"
#include <cmath>
#include <algorithm>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// ZClip: host-side controller
// ─────────────────────────────────────────────────────────────────────────────
struct ZClipState {
    WelfordState norm_stats;  // running statistics of gradient norms
    float k = 6.0f;           // clip at mean + k * sigma (default: 6-sigma)
    float warmup_min = 50;    // minimum observations before clipping activates
    int   total_clips = 0;
    int   total_steps = 0;

    /// Compute the adaptive clip threshold
    float threshold() const {
        if (norm_stats.n < static_cast<uint64_t>(warmup_min))
            return 1e9f; // Don't clip during warmup
        double mu  = norm_stats.mean;
        double sig = norm_stats.std_dev();
        return static_cast<float>(mu + k * sig);
    }

    /// Observe a new gradient norm and return whether it was clipped
    bool observe_and_check(float grad_norm) {
        norm_stats.update(static_cast<double>(grad_norm));
        ++total_steps;
        bool clipped = (grad_norm > threshold());
        if (clipped) ++total_clips;
        return clipped;
    }

    /// Return the scaling factor to apply to gradients
    /// If grad_norm <= threshold: returns 1.0
    /// If grad_norm >  threshold: returns threshold / grad_norm
    float clip_factor(float grad_norm) const {
        float t = threshold();
        return (grad_norm > t) ? t / grad_norm : 1.0f;
    }

    float clip_rate() const {
        return total_steps > 0
            ? static_cast<float>(total_clips) / static_cast<float>(total_steps)
            : 0.0f;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// CPU implementation: clip a flat gradient array
// ─────────────────────────────────────────────────────────────────────────────
inline float compute_grad_norm_cpu(const float* g, int n) {
    float ss = 0.0f;
    for (int i = 0; i < n; ++i) ss += g[i] * g[i];
    return std::sqrt(ss);
}

inline bool zclip_apply_cpu(float* g, int n, ZClipState& state) {
    float norm = compute_grad_norm_cpu(g, n);
    float factor = 1.0f;
    bool clipped = state.observe_and_check(norm);
    if (clipped) factor = state.threshold() / norm;
    if (factor < 1.0f) {
        for (int i = 0; i < n; ++i) g[i] *= factor;
    }
    return clipped;
}

// ─────────────────────────────────────────────────────────────────────────────
// AGC: unit-wise (row-wise) adaptive gradient clipping
// ─────────────────────────────────────────────────────────────────────────────
inline void agc_apply_cpu(float* grad, const float* weight,
                           int rows, int cols,
                           float lambda = 0.01f)
{
    for (int i = 0; i < rows; ++i) {
        const float* w_row = weight + i * cols;
        float*       g_row = grad   + i * cols;

        float w_norm_sq = 0.0f, g_norm_sq = 0.0f;
        for (int j = 0; j < cols; ++j) {
            w_norm_sq += w_row[j] * w_row[j];
            g_norm_sq += g_row[j] * g_row[j];
        }
        float w_norm = std::sqrt(w_norm_sq);
        float g_norm = std::sqrt(g_norm_sq);
        float threshold = lambda * w_norm;

        if (g_norm > threshold && g_norm > 1e-6f) {
            float scale = threshold / g_norm;
            for (int j = 0; j < cols; ++j)
                g_row[j] *= scale;
        }
    }
}

#ifdef __CUDACC__

// ─────────────────────────────────────────────────────────────────────────────
// GPU kernels
// ─────────────────────────────────────────────────────────────────────────────

/// Compute global gradient L2 norm squared (reduction kernel)
__global__
void grad_norm_sq_kernel(const float* __restrict__ g, float* __restrict__ out, int n) {
    __shared__ float smem[256];
    float local = 0.0f;
    for (int i = blockIdx.x * blockDim.x + threadIdx.x; i < n;
         i += blockDim.x * gridDim.x)
        local += g[i] * g[i];
    smem[threadIdx.x] = local;
    __syncthreads();
    for (int s = blockDim.x/2; s > 0; s >>= 1) {
        if (threadIdx.x < s) smem[threadIdx.x] += smem[threadIdx.x + s];
        __syncthreads();
    }
    if (threadIdx.x == 0) atomicAdd(out, smem[0]);
}

/// Apply global scale factor to gradient
__global__
void grad_scale_kernel(float* g, float factor, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i < n) g[i] *= factor;
}

/// AGC: row-wise gradient clipping relative to weight norm
/// Each block handles one row of [rows x cols]
__global__
void agc_kernel(float*       __restrict__ grad,    // [rows x cols]
                const float* __restrict__ weight,  // [rows x cols]
                float lambda, int rows, int cols)
{
    int row = blockIdx.x;
    if (row >= rows) return;

    float* g_row       = grad   + row * cols;
    const float* w_row = weight + row * cols;

    // Compute row norms via warp reduction
    float g_ss = 0.0f, w_ss = 0.0f;
    for (int c = threadIdx.x; c < cols; c += blockDim.x) {
        g_ss += g_row[c] * g_row[c];
        w_ss += w_row[c] * w_row[c];
    }
    for (int off = 16; off >= 1; off >>= 1) {
        g_ss += __shfl_xor_sync(0xFFFFFFFF, g_ss, off);
        w_ss += __shfl_xor_sync(0xFFFFFFFF, w_ss, off);
    }

    // Thread 0 computes scale
    __shared__ float scale;
    if (threadIdx.x == 0) {
        float g_norm    = sqrtf(g_ss);
        float w_norm    = sqrtf(w_ss);
        float threshold = lambda * w_norm;
        scale = (g_norm > threshold && g_norm > 1e-6f) ? threshold / g_norm : 1.0f;
    }
    __syncthreads();

    if (scale < 1.0f) {
        for (int c = threadIdx.x; c < cols; c += blockDim.x)
            g_row[c] *= scale;
    }
}

/// ZClip: compute global norm, update host-side Welford, apply clip
/// Note: ZClipState maintained on host; this kernel just computes the norm.
inline float zclip_compute_norm_gpu(const float* d_g, int n,
                                     cudaStream_t stream = nullptr)
{
    float* d_norm;
    SGF_CUDA_CHECK(cudaMalloc(&d_norm, sizeof(float)));
    SGF_CUDA_CHECK(cudaMemsetAsync(d_norm, 0, sizeof(float), stream));

    int blk = 256, grd = std::min((n + blk - 1) / blk, 65535);
    grad_norm_sq_kernel<<<grd, blk, 0, stream>>>(d_g, d_norm, n);

    float norm_sq;
    SGF_CUDA_CHECK(cudaMemcpyAsync(&norm_sq, d_norm, sizeof(float),
                                    cudaMemcpyDeviceToHost, stream));
    SGF_CUDA_CHECK(cudaStreamSynchronize(stream));
    cudaFree(d_norm);
    return std::sqrt(norm_sq);
}

inline bool zclip_apply_gpu(float* d_g, int n, ZClipState& state,
                              cudaStream_t stream = nullptr)
{
    float norm   = zclip_compute_norm_gpu(d_g, n, stream);
    bool clipped = state.observe_and_check(norm);
    if (clipped) {
        float factor = state.threshold() / norm;
        grad_scale_kernel<<<(n+255)/256, 256, 0, stream>>>(d_g, factor, n);
    }
    return clipped;
}

inline void agc_apply_gpu(float* d_grad, const float* d_weight,
                           int rows, int cols, float lambda = 0.01f,
                           cudaStream_t stream = nullptr)
{
    int block = std::min(cols, 256);
    agc_kernel<<<rows, block, 0, stream>>>(d_grad, d_weight, lambda, rows, cols);
}

// ─────────────────────────────────────────────────────────────────────────────
// AdaGC: per-parameter EMA-adaptive clipping
// Tracks EMA of gradient norm per layer; clips when current > EMA * factor
// ─────────────────────────────────────────────────────────────────────────────
struct AdaGCState {
    float ema_norm    = -1.0f;  // -1 = uninitialised
    float beta        = 0.999f; // EMA decay
    float clip_factor = 5.0f;   // clip at ema_norm * clip_factor

    bool update_and_clip(float* g_ptr, int n) {
        // Compute norm
        float norm = 0.0f;
        for (int i = 0; i < n; ++i) norm += g_ptr[i] * g_ptr[i];
        norm = std::sqrt(norm);

        if (ema_norm < 0.0f) { ema_norm = norm; return false; }

        ema_norm = beta * ema_norm + (1.0f - beta) * norm;
        float threshold = ema_norm * clip_factor;
        if (norm > threshold && norm > 1e-6f) {
            float scale = threshold / norm;
            for (int i = 0; i < n; ++i) g_ptr[i] *= scale;
            return true;
        }
        return false;
    }
};

#endif // __CUDACC__

} // namespace sgf
