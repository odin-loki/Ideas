#pragma once
/**
 * sgf/sgf.h — Streaming Geometry Framework: Master Orchestrator
 *
 * Ties together all four SGF layers:
 *
 *   Physical Layer:  Fused kernels, tiled matmuls, KV cache management
 *                    → welford.cuh, online_softmax.cuh
 *
 *   Metric Layer:    Fisher estimator, Welford normaliser, sharpness tracker
 *                    → kfac.cuh, wsd.h (EoSMonitor)
 *
 *   Dynamics Layer:  Muon/Adam/SOAP optimizer, ZClip, WSD schedule
 *                    → muon.cuh, zclip.cuh, wsd.h
 *
 *   Control Layer:   MoE router, speculative decoding, data sampler
 *                    → moe.cuh, speculative.h
 *
 * All four layers communicate via sufficient statistics, never raw tensors.
 * The SGFOrchestrator provides a unified step() interface that:
 *   1. Observes gradients and routes through the Metric Layer
 *   2. Applies ZClip (Dynamics Layer)
 *   3. Applies Muon or Adam preconditioner (Dynamics Layer)
 *   4. Steps the WSD schedule (Dynamics Layer)
 *   5. Updates MoE load stats (Control Layer)
 *   6. Returns a structured report of all IRE sufficient statistics
 */

#include "ire.h"
#include "welford.cuh"
#include "online_softmax.cuh"
#include "muon.cuh"
#include "kfac.cuh"
#include "zclip.cuh"
#include "wsd.h"
#include "checkpoint.h"
#include "moe.cuh"
#include "speculative.h"
#include "algebraic_layer.cuh"   // Autopsy-derived algebra-aware layers
#include "spectral_monitor.cuh"  // Online α / MP / algebra-class monitoring

#include <vector>
#include <string>
#include <unordered_map>
#include <memory>
#include <functional>
#include <cstdint>
#include <cstdio>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Per-parameter-group optimizer selection (spectral transform family)
// ─────────────────────────────────────────────────────────────────────────────
enum class OptimizerType {
    MUON,       // UΣ^0 V^T — weight matrices (Stiefel manifold)
    ADAM,       // Diagonal Fisher — embeddings, LayerNorm, biases
    KFAC,       // Kronecker Fisher — linear layers with K-FAC metric
    SIGN_SGD    // sign(g) — coordinate-wise whitening, biases only
};

struct ParamGroup {
    std::string    name;
    int            rows, cols;        // weight matrix shape
    OptimizerType  optimizer;
    float          lr_scale = 1.0f;  // per-group learning rate multiplier
    bool           apply_agc = true; // false for embedding / final linear
};

// ─────────────────────────────────────────────────────────────────────────────
// SGF training step report: IRE sufficient statistics from all layers
// ─────────────────────────────────────────────────────────────────────────────
struct SGFStepReport {
    uint64_t global_step;
    float    learning_rate;
    TrainingPhase phase;

    // Metric Layer
    float    grad_norm;
    bool     grad_clipped;
    float    zclip_threshold;

    // Dynamics Layer
    float    sharpness_lambda_max;  // EoS monitor
    SharpnessRegime sharpness_regime;

    // Control Layer
    float    moe_aux_loss;
    bool     moe_balanced;
    float    spec_acceptance_rate;

    // Memory
    uint64_t activation_bytes_stored;
};

// ─────────────────────────────────────────────────────────────────────────────
// SGF full configuration
// ─────────────────────────────────────────────────────────────────────────────
struct SGFConfig {
    // Optimizer
    std::vector<ParamGroup> param_groups;

    // ZClip
    float   zclip_k              = 6.0f;
    int     zclip_warmup_steps   = 50;

    // WSD
    WSDConfig wsd;

    // AGC
    float   agc_lambda           = 0.01f;

    // K-FAC
    float   kfac_ema_beta        = 0.95f;
    int     kfac_update_freq     = 10;

    // MoE
    MoEConfig moe;

    // Checkpointing
    double  ridge_point          = 200.0;  // FLOP/byte — hardware dependent

    // Memory budget (bytes) — 0 = unlimited
    uint64_t max_activation_bytes = 0;

    // Logging
    int     log_interval         = 100;
    bool    verbose              = false;
};

// ─────────────────────────────────────────────────────────────────────────────
// SGFOrchestrator: unified host-side controller
// ─────────────────────────────────────────────────────────────────────────────
class SGFOrchestrator {
public:
    explicit SGFOrchestrator(SGFConfig cfg)
        : cfg_(std::move(cfg))
        , wsd_(cfg_.wsd)
        , moe_router_(cfg_.moe)
        , checkpoint_mgr_(cfg_.ridge_point)
    {
        // Initialise ZClip state
        zclip_.k            = cfg_.zclip_k;
        zclip_.warmup_min   = cfg_.zclip_warmup_steps;

        // Initialise per-group Adam moment buffers
        for (auto& pg : cfg_.param_groups) {
            if (pg.optimizer == OptimizerType::ADAM) {
                int n = pg.rows * pg.cols;
                adam_m1_[pg.name].assign(n, 0.0f);
                adam_m2_[pg.name].assign(n, 0.0f);
            }
        }
    }

    /// One complete training step (host/CPU path).
    /// grads: map from param group name to flat gradient array
    /// weights: map from param group name to flat weight array (updated in-place)
    SGFStepReport step(
        std::unordered_map<std::string, float*>& grads,
        std::unordered_map<std::string, float*>& weights)
    {
        // ── 1. Compute global gradient norm (across all groups) ──
        double global_ss = 0.0;
        for (auto& pg : cfg_.param_groups) {
            float* g = grads.at(pg.name);
            int n = pg.rows * pg.cols;
            for (int i = 0; i < n; ++i)
                global_ss += static_cast<double>(g[i]) * g[i];
        }
        float global_norm = static_cast<float>(std::sqrt(global_ss));

        // ── 2. ZClip: update Welford stats and compute clip factor ──
        bool clipped = zclip_.observe_and_check(global_norm);
        float clip_factor = zclip_.clip_factor(global_norm);

        if (clip_factor < 1.0f) {
            for (auto& pg : cfg_.param_groups) {
                float* g = grads.at(pg.name);
                int n = pg.rows * pg.cols;
                for (int i = 0; i < n; ++i) g[i] *= clip_factor;
                global_norm *= clip_factor;
            }
        }

        // ── 3. Get current learning rate from WSD ──
        float lr = wsd_.step(&zclip_);

        // ── 4. Apply per-group optimizer ──
        ++global_step_;
        for (auto& pg : cfg_.param_groups) {
            float* g = grads.at(pg.name);
            float* w = weights.at(pg.name);
            int n = pg.rows * pg.cols;
            float eff_lr = lr * pg.lr_scale;

            switch (pg.optimizer) {
                case OptimizerType::MUON:
                    // Host-side Newton-Schulz (slow — use MuonOptimizerGPU for real training)
                    if (pg.apply_agc)
                        agc_apply_cpu(g, w, pg.rows, pg.cols, cfg_.agc_lambda);
                    newton_schulz_cpu(g, pg.rows, pg.cols, 5);
                    for (int i = 0; i < n; ++i) w[i] -= eff_lr * g[i];
                    break;

                case OptimizerType::ADAM:
                    adam_step_cpu(pg.name, g, w, n, eff_lr);
                    break;

                case OptimizerType::SIGN_SGD:
                    for (int i = 0; i < n; ++i)
                        w[i] -= eff_lr * (g[i] > 0 ? 1.0f : g[i] < 0 ? -1.0f : 0.0f);
                    break;

                case OptimizerType::KFAC: {
                    auto it = kfac_layers_.find(pg.name);
                    if (it != kfac_layers_.end()) {
                        std::vector<float> precond(n);
                        it->second.precondition(g, precond.data());
                        if (pg.apply_agc)
                            agc_apply_cpu(precond.data(), w, pg.rows, pg.cols, cfg_.agc_lambda);
                        for (int i = 0; i < n; ++i) w[i] -= eff_lr * precond[i];
                    } else {
                        // Fall back to SGD if K-FAC not initialised
                        for (int i = 0; i < n; ++i) w[i] -= eff_lr * g[i];
                    }
                    break;
                }
            }
        }

        // ── 5. Update EoS monitor (user should pass sharpness estimate externally) ──
        SharpnessRegime regime = eos_.regime(lr);
        checkpoint_mgr_.adapt_to_regime(regime);

        // ── 6. Log periodically ──
        if (cfg_.verbose && global_step_ % cfg_.log_interval == 0) {
            printf("[SGF step=%lu phase=%s lr=%.2e grad_norm=%.4f clip=%s "
                   "lambda_max=%.2f]\n",
                   (unsigned long)global_step_,
                   phase_name(wsd_.phase()),
                   static_cast<double>(lr),
                   static_cast<double>(global_norm),
                   clipped ? "YES" : "no",
                   static_cast<double>(eos_.lambda_max_ema));
        }

        return {
            global_step_,
            lr,
            wsd_.phase(),
            global_norm,
            clipped,
            zclip_.threshold(),
            eos_.lambda_max_ema,
            regime,
            moe_router_.aux_loss(),
            moe_router_.is_balanced(),
            0.0f,  // speculative acceptance: set by calling code
            checkpoint_mgr_.peak_activation_bytes()
        };
    }

    /// Register a K-FAC layer (call once per layer before training)
    void register_kfac_layer(const std::string& name, int d_in, int d_out) {
        kfac_layers_[name].init(d_in, d_out, cfg_.kfac_ema_beta, cfg_.kfac_update_freq);
    }

    /// Feed forward activations to K-FAC (call during each forward pass)
    void kfac_observe(const std::string& name, const float* a, const float* ds) {
        auto it = kfac_layers_.find(name);
        if (it != kfac_layers_.end()) it->second.observe(a, ds);
    }

    /// Feed external sharpness estimate (from power iteration or HVP)
    void update_sharpness(float lambda_max) { eos_.update(lambda_max); }

    /// Trigger WSD cooldown manually
    void trigger_cooldown() { wsd_.trigger_cooldown(); }

    /// Create a fork of this orchestrator in cooldown phase (for checkpoint branching)
    SGFOrchestrator fork() const {
        SGFConfig fork_cfg = cfg_;
        SGFOrchestrator fork(std::move(fork_cfg));
        fork.wsd_         = wsd_.fork_cooldown();
        fork.global_step_ = global_step_;
        fork.zclip_       = zclip_;
        fork.eos_         = eos_;
        return fork;
    }

    // Accessors
    const WSDScheduler&    wsd()         const { return wsd_; }
    const ZClipState&      zclip()       const { return zclip_; }
    const EoSMonitor&      eos_monitor() const { return eos_; }
    const MoERouter&       moe()         const { return moe_router_; }
    const CheckpointManager& checkpoint() const { return checkpoint_mgr_; }
    uint64_t global_step()               const { return global_step_; }

private:
    void adam_step_cpu(const std::string& name, float* g, float* w, int n,
                        float lr, float b1 = 0.9f, float b2 = 0.999f,
                        float eps = 1e-8f)
    {
        auto& m1 = adam_m1_.at(name);
        auto& m2 = adam_m2_.at(name);
        float bc1 = 1.0f - std::pow(b1, static_cast<float>(adam_step_count_ + 1));
        float bc2 = 1.0f - std::pow(b2, static_cast<float>(adam_step_count_ + 1));
        for (int i = 0; i < n; ++i) {
            m1[i] = b1 * m1[i] + (1.0f - b1) * g[i];
            m2[i] = b2 * m2[i] + (1.0f - b2) * g[i] * g[i];
            float m1h = m1[i] / bc1;
            float m2h = m2[i] / bc2;
            w[i] -= lr * m1h / (std::sqrt(m2h) + eps);
        }
        ++adam_step_count_;
    }

    SGFConfig    cfg_;
    WSDScheduler wsd_;
    ZClipState   zclip_;
    EoSMonitor   eos_;
    MoERouter    moe_router_;
    CheckpointManager checkpoint_mgr_;

    std::unordered_map<std::string, KFACLayer>           kfac_layers_;
    std::unordered_map<std::string, std::vector<float>>  adam_m1_, adam_m2_;

    uint64_t global_step_     = 0;
    uint64_t adam_step_count_ = 0;
};

// ─────────────────────────────────────────────────────────────────────────────
// Convenience: default SGF config for a transformer-style model
// ─────────────────────────────────────────────────────────────────────────────
inline SGFConfig default_transformer_config(
    int n_layers,
    int d_model,
    int d_ffn,
    int n_heads,
    int n_experts = 0,
    float base_lr  = 3e-4f)
{
    SGFConfig cfg;

    // WSD schedule
    cfg.wsd.lr_max         = base_lr;
    cfg.wsd.lr_min         = base_lr * 0.1f;
    cfg.wsd.warmup_steps   = 500;
    cfg.wsd.cooldown_steps = 1000;
    cfg.wsd.auto_cooldown  = true;  // use ZClip trigger

    // MoE
    if (n_experts > 0) {
        cfg.moe.n_experts = n_experts;
        cfg.moe.top_k     = 2;
        cfg.moe.router    = RouterType::TOP_K;
    }

    // Register param groups per transformer block
    for (int l = 0; l < n_layers; ++l) {
        std::string prefix = "layer" + std::to_string(l) + ".";

        // Attention weight matrices → Muon (Stiefel manifold)
        cfg.param_groups.push_back({prefix + "attn.Wq", n_heads, d_model, OptimizerType::MUON});
        cfg.param_groups.push_back({prefix + "attn.Wk", n_heads, d_model, OptimizerType::MUON});
        cfg.param_groups.push_back({prefix + "attn.Wv", n_heads, d_model, OptimizerType::MUON});
        cfg.param_groups.push_back({prefix + "attn.Wo", d_model, n_heads, OptimizerType::MUON});

        // FFN weight matrices → Muon
        cfg.param_groups.push_back({prefix + "ffn.W1", d_ffn,   d_model, OptimizerType::MUON});
        cfg.param_groups.push_back({prefix + "ffn.W2", d_model, d_ffn,   OptimizerType::MUON});

        // LayerNorm → Adam (diagonal)
        cfg.param_groups.push_back({prefix + "ln1.weight", 1, d_model, OptimizerType::ADAM,
                                     1.0f, false});
        cfg.param_groups.push_back({prefix + "ln2.weight", 1, d_model, OptimizerType::ADAM,
                                     1.0f, false});
    }

    // Embedding → Adam (no AGC — rare token norms inflated)
    cfg.param_groups.push_back({"embed.weight", 1, d_model, OptimizerType::ADAM,
                                  1.0f, false});

    // Final logit head → Adam (no Muon, no AGC)
    cfg.param_groups.push_back({"head.weight", d_model, 1, OptimizerType::ADAM,
                                  1.0f, false});

    // Hardware defaults (H100 SXM5)
    cfg.ridge_point = 60.0;  // ~60 FLOP/byte on H100

    return cfg;
}

} // namespace sgf
