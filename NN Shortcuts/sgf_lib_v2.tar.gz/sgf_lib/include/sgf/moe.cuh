#pragma once
/**
 * sgf/moe.cuh — Mixture-of-Experts router with online load balancing
 *
 * IRE instance:
 *   M    = Expert activation manifold (sparse probability simplex)
 *   S    = (gating logits G, load_ema per expert)   — N_experts scalars each
 *   T    = Forward: update gating softmax; Backward: update load EMA
 *   phi  = top-k expert selection + capacity enforcement
 *
 * Routing variants implemented:
 *   TOP_K       — standard softmax + top-k (Mixtral style)
 *   EXPERT_CHOICE — experts select top-k tokens (fixed capacity, no overflow)
 *   NOISY_TOP_K — add noise during training for exploration (Switch style)
 *
 * Load balancing:
 *   Auxiliary loss = alpha * N * sum_i(f_i * P_i)
 *   f_i  = fraction of tokens dispatched to expert i
 *   P_i  = mean routing probability for expert i
 *   Tracked online via EMA sufficient statistics.
 */

#include "ire.h"
#include "online_softmax.cuh"
#include "welford.cuh"
#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include <cassert>
#include <random>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// MoE configuration
// ─────────────────────────────────────────────────────────────────────────────
enum class RouterType {
    TOP_K,
    EXPERT_CHOICE,
    NOISY_TOP_K
};

struct MoEConfig {
    int         n_experts      = 8;
    int         top_k          = 2;        // experts selected per token
    float       capacity_factor = 1.25f;  // overflow tolerance (ExpertChoice: ignored)
    RouterType  router          = RouterType::TOP_K;
    float       noise_std       = 1e-2f;  // for NOISY_TOP_K
    float       load_ema_beta   = 0.99f;  // EMA decay for load tracker
    float       aux_loss_alpha  = 1e-2f;  // load balancing loss coefficient
};

// ─────────────────────────────────────────────────────────────────────────────
// Per-expert statistics (online load tracker — IRE sufficient statistic)
// ─────────────────────────────────────────────────────────────────────────────
struct ExpertLoadState {
    float dispatch_fraction = 0.0f;  // f_i: EMA fraction of tokens routed here
    float mean_prob         = 0.0f;  // P_i: EMA mean routing probability
    uint64_t total_tokens   = 0;     // cumulative tokens dispatched
};

// ─────────────────────────────────────────────────────────────────────────────
// Routing result for one token
// ─────────────────────────────────────────────────────────────────────────────
struct TokenRoute {
    int   expert_ids[8];   // selected expert indices (top_k of them are valid)
    float expert_weights[8]; // corresponding probabilities (normalised to sum=1)
    int   n_selected;
};

// ─────────────────────────────────────────────────────────────────────────────
// Host-side MoE router
// ─────────────────────────────────────────────────────────────────────────────
class MoERouter {
public:
    explicit MoERouter(MoEConfig cfg = {})
        : cfg_(cfg), load_(cfg.n_experts), rng_(42)
    {}

    /// Route a batch of tokens.
    /// logits: [n_tokens x n_experts] row-major
    /// Returns routes[n_tokens] and updates load statistics.
    std::vector<TokenRoute> route(const float* logits, int n_tokens) {
        std::vector<TokenRoute> routes(n_tokens);

        switch (cfg_.router) {
            case RouterType::TOP_K:
                route_topk(logits, n_tokens, routes);
                break;
            case RouterType::NOISY_TOP_K:
                route_noisy_topk(logits, n_tokens, routes);
                break;
            case RouterType::EXPERT_CHOICE:
                route_expert_choice(logits, n_tokens, routes);
                break;
        }

        update_load(routes, logits, n_tokens);
        return routes;
    }

    /// Compute auxiliary load-balancing loss (scalar)
    float aux_loss() const {
        float loss = 0.0f;
        for (int e = 0; e < cfg_.n_experts; ++e)
            loss += load_[e].dispatch_fraction * load_[e].mean_prob;
        return cfg_.aux_loss_alpha * static_cast<float>(cfg_.n_experts) * loss;
    }

    const ExpertLoadState& expert_state(int e) const { return load_[e]; }
    const MoEConfig& config() const { return cfg_; }

    /// Check if load is balanced (no expert over 2x mean utilisation)
    bool is_balanced(float tolerance = 2.0f) const {
        float mean = 1.0f / static_cast<float>(cfg_.n_experts);
        for (int e = 0; e < cfg_.n_experts; ++e)
            if (load_[e].dispatch_fraction > tolerance * mean) return false;
        return true;
    }

private:
    void softmax_row(const float* logits, float* probs, int n) {
        // Online softmax
        OnlineSoftmaxState smx;
        for (int i = 0; i < n; ++i) smx.update(logits[i]);
        for (int i = 0; i < n; ++i)
            probs[i] = smx.softmax_val(logits[i]);
    }

    void route_topk(const float* logits, int n_tokens,
                    std::vector<TokenRoute>& routes)
    {
        std::vector<float> probs(cfg_.n_experts);
        for (int t = 0; t < n_tokens; ++t) {
            softmax_row(logits + t * cfg_.n_experts, probs.data(), cfg_.n_experts);
            fill_topk(probs.data(), routes[t]);
        }
    }

    void route_noisy_topk(const float* logits, int n_tokens,
                           std::vector<TokenRoute>& routes)
    {
        std::normal_distribution<float> noise(0.0f, cfg_.noise_std);
        std::vector<float> noisy(cfg_.n_experts);
        std::vector<float> probs(cfg_.n_experts);
        for (int t = 0; t < n_tokens; ++t) {
            for (int e = 0; e < cfg_.n_experts; ++e)
                noisy[e] = logits[t * cfg_.n_experts + e] + noise(rng_);
            softmax_row(noisy.data(), probs.data(), cfg_.n_experts);
            fill_topk(probs.data(), routes[t]);
        }
    }

    void route_expert_choice(const float* logits, int n_tokens,
                              std::vector<TokenRoute>& routes)
    {
        // Expert choice: each expert selects its top-k tokens
        // capacity = top_k * n_tokens / n_experts
        int capacity = std::max(1,
            static_cast<int>(cfg_.top_k * n_tokens / cfg_.n_experts));

        // For each expert, compute scores and pick top-capacity tokens
        std::vector<std::vector<std::pair<float, int>>> expert_scores(cfg_.n_experts);
        for (int e = 0; e < cfg_.n_experts; ++e)
            expert_scores[e].reserve(n_tokens);

        for (int t = 0; t < n_tokens; ++t) {
            const float* row = logits + t * cfg_.n_experts;
            for (int e = 0; e < cfg_.n_experts; ++e)
                expert_scores[e].push_back({row[e], t});
        }

        // Each expert selects its top `capacity` tokens
        for (int e = 0; e < cfg_.n_experts; ++e) {
            auto& scores = expert_scores[e];
            std::partial_sort(scores.begin(),
                              scores.begin() + std::min(capacity, (int)scores.size()),
                              scores.end(),
                              [](auto& a, auto& b){ return a.first > b.first; });
        }

        // Build token routes (each token gets a list of experts that selected it)
        for (int t = 0; t < n_tokens; ++t) {
            routes[t].n_selected = 0;
        }
        for (int e = 0; e < cfg_.n_experts; ++e) {
            int cap = std::min(capacity, (int)expert_scores[e].size());
            for (int i = 0; i < cap; ++i) {
                int t = expert_scores[e][i].second;
                int k = routes[t].n_selected;
                if (k < cfg_.top_k) {
                    routes[t].expert_ids[k]     = e;
                    routes[t].expert_weights[k] = expert_scores[e][i].first;
                    ++routes[t].n_selected;
                }
            }
        }
        // Normalise weights
        for (int t = 0; t < n_tokens; ++t) {
            float wsum = 0.0f;
            for (int k = 0; k < routes[t].n_selected; ++k)
                wsum += routes[t].expert_weights[k];
            if (wsum > 1e-8f)
                for (int k = 0; k < routes[t].n_selected; ++k)
                    routes[t].expert_weights[k] /= wsum;
        }
    }

    void fill_topk(const float* probs, TokenRoute& route) {
        // Find top-k indices — O(n_experts * k), fine for k<=8, n_experts<=256
        route.n_selected = cfg_.top_k;
        std::vector<int> indices(cfg_.n_experts);
        for (int e = 0; e < cfg_.n_experts; ++e) indices[e] = e;
        std::partial_sort(indices.begin(), indices.begin() + cfg_.top_k,
                          indices.end(),
                          [&](int a, int b){ return probs[a] > probs[b]; });
        float wsum = 0.0f;
        for (int k = 0; k < cfg_.top_k; ++k) {
            route.expert_ids[k]     = indices[k];
            route.expert_weights[k] = probs[indices[k]];
            wsum += route.expert_weights[k];
        }
        for (int k = 0; k < cfg_.top_k; ++k)
            route.expert_weights[k] /= wsum;
    }

    void update_load(const std::vector<TokenRoute>& routes,
                     const float* logits, int n_tokens)
    {
        float beta  = cfg_.load_ema_beta;
        float ob    = 1.0f - beta;
        int   ne    = cfg_.n_experts;
        float inv_t = 1.0f / static_cast<float>(std::max(1, n_tokens));

        std::vector<float> dispatch_count(ne, 0.0f);
        for (auto& r : routes)
            for (int k = 0; k < r.n_selected; ++k)
                dispatch_count[r.expert_ids[k]] += 1.0f;

        // Compute mean routing probability per expert across batch
        std::vector<float> mean_prob(ne, 0.0f);
        std::vector<float> probs(ne);
        for (int t = 0; t < n_tokens; ++t) {
            OnlineSoftmaxState smx;
            for (int e = 0; e < ne; ++e) smx.update(logits[t * ne + e]);
            for (int e = 0; e < ne; ++e)
                mean_prob[e] += smx.softmax_val(logits[t * ne + e]);
        }

        for (int e = 0; e < ne; ++e) {
            float f = dispatch_count[e] * inv_t;
            float p = mean_prob[e]      * inv_t;
            load_[e].dispatch_fraction = beta * load_[e].dispatch_fraction + ob * f;
            load_[e].mean_prob         = beta * load_[e].mean_prob         + ob * p;
            load_[e].total_tokens     += static_cast<uint64_t>(dispatch_count[e]);
        }
    }

    MoEConfig                cfg_;
    std::vector<ExpertLoadState> load_;
    std::mt19937              rng_;
};

#ifdef __CUDACC__

// ─────────────────────────────────────────────────────────────────────────────
// GPU top-k routing kernel
// logits:      [n_tokens x n_experts]  float32
// out_ids:     [n_tokens x top_k]      int32   — selected expert indices
// out_weights: [n_tokens x top_k]      float32 — normalised weights
// ─────────────────────────────────────────────────────────────────────────────
template <int TOP_K, int N_EXPERTS>
__global__
void moe_topk_kernel(const float* __restrict__ logits,
                      int*         __restrict__ out_ids,
                      float*       __restrict__ out_weights,
                      int n_tokens)
{
    static_assert(TOP_K <= N_EXPERTS, "top_k must be <= n_experts");
    int token = blockIdx.x * blockDim.x + threadIdx.x;
    if (token >= n_tokens) return;

    const float* row = logits + token * N_EXPERTS;

    // ── Online softmax for this token ──
    OnlineSoftmaxState smx;
    for (int e = 0; e < N_EXPERTS; ++e) smx.update(row[e]);

    // ── Find top-k via register-resident sorting network ──
    // (Use partial insertion sort — fine for N_EXPERTS <= 256, TOP_K <= 8)
    float top_vals[TOP_K];
    int   top_idx[TOP_K];
    for (int k = 0; k < TOP_K; ++k) {
        top_vals[k] = -FLT_MAX;
        top_idx[k]  = -1;
    }

    for (int e = 0; e < N_EXPERTS; ++e) {
        float p = smx.softmax_val(row[e]);
        if (p > top_vals[TOP_K - 1]) {
            top_vals[TOP_K - 1] = p;
            top_idx[TOP_K - 1]  = e;
            // Bubble up
            for (int k = TOP_K - 1; k > 0; --k) {
                if (top_vals[k] > top_vals[k-1]) {
                    float tv = top_vals[k]; top_vals[k] = top_vals[k-1]; top_vals[k-1] = tv;
                    int   ti = top_idx[k];  top_idx[k]  = top_idx[k-1];  top_idx[k-1]  = ti;
                } else break;
            }
        }
    }

    // ── Normalise top-k weights to sum=1 ──
    float wsum = 0.0f;
    for (int k = 0; k < TOP_K; ++k) wsum += top_vals[k];
    float inv_wsum = (wsum > 1e-8f) ? 1.0f / wsum : 0.0f;

    for (int k = 0; k < TOP_K; ++k) {
        out_ids    [token * TOP_K + k] = top_idx[k];
        out_weights[token * TOP_K + k] = top_vals[k] * inv_wsum;
    }
}

/// GPU load tracker: update EMA dispatch fractions from routing output
/// out_ids: [n_tokens x top_k], d_load_ema: [n_experts]
__global__
void moe_update_load_kernel(const int* __restrict__ out_ids,
                              float*     __restrict__ d_load_ema,
                              float beta, float one_minus_beta,
                              int n_tokens, int top_k, int n_experts)
{
    // One thread per expert — accumulate its dispatch count
    int e = blockIdx.x * blockDim.x + threadIdx.x;
    if (e >= n_experts) return;

    int count = 0;
    for (int t = 0; t < n_tokens; ++t)
        for (int k = 0; k < top_k; ++k)
            if (out_ids[t * top_k + k] == e) ++count;

    float f = static_cast<float>(count) / static_cast<float>(n_tokens);
    d_load_ema[e] = beta * d_load_ema[e] + one_minus_beta * f;
}

// ─────────────────────────────────────────────────────────────────────────────
// Host launchers for GPU MoE
// ─────────────────────────────────────────────────────────────────────────────
template <int TOP_K = 2, int N_EXPERTS = 8>
inline void launch_moe_topk(const float* d_logits, int* d_ids, float* d_weights,
                              int n_tokens, cudaStream_t stream = nullptr)
{
    int block = 128;
    int grid  = (n_tokens + block - 1) / block;
    moe_topk_kernel<TOP_K, N_EXPERTS><<<grid, block, 0, stream>>>(
        d_logits, d_ids, d_weights, n_tokens);
}

inline void launch_moe_load_update(const int* d_ids, float* d_load_ema,
                                    float beta, int n_tokens, int top_k,
                                    int n_experts, cudaStream_t stream = nullptr)
{
    moe_update_load_kernel<<<(n_experts+31)/32, 32, 0, stream>>>(
        d_ids, d_load_ema, beta, 1.0f - beta, n_tokens, top_k, n_experts);
}

#endif // __CUDACC__

} // namespace sgf
