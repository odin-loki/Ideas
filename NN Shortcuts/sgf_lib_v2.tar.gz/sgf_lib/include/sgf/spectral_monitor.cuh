#pragma once
/**
 * sgf/spectral_monitor.cuh — Online spectral health monitoring for SGF
 *
 * Derived from the Algebraic Autopsy of Trained Neural Networks (2025).
 * Tracks the spectral signatures that distinguish algebra classes in trained nets.
 *
 * === Spectral Findings from the Autopsy ===
 *   α (power-law exponent of singular value spectrum):
 *     Data prior (prime gaps):   α = 0.37
 *     Baseline MLP (dense):      α = 0.427   (per-layer: 0.31 → 0.43 → 0.54)
 *     Low-rank constrained:      α = 1.223   (Grassmannian regularisation effect)
 *     Cypha HRNA reference:      α = 0.85
 *
 *   Marchenko-Pastur (MP) bulk:
 *     Only 24.2% of Frobenius mass is signal (above MP threshold)
 *     75.8% is noise-consistent bulk
 *
 *   Layer-4 singular value concentration:
 *     Largest SV is 63× the MP threshold → single dominant direction
 *
 * === IRE Instances ===
 *
 * 1. SpectralPowerLawMonitor
 *    M  = RealLine (α ∈ ℝ)
 *    S  = (log σ values, OLS sufficient stats: Σ log k, Σ log σ, Σ (log k)², n)
 *    T  = O(r) online update when new SVs are observed
 *    φ  = α = -slope of log-log rank-vs-SV regression
 *
 * 2. MarchenkoPasturMonitor
 *    M  = PSD (empirical spectral distribution)
 *    S  = (n, p, σ² estimate from bulk, Frobenius norm)
 *    T  = O(r) scan of SVs against MP bound
 *    φ  = signal fraction = ||W_signal||²_F / ||W||²_F
 *
 * 3. AlgebraClassifier
 *    M  = Simplex over algebra classes
 *    S  = (α, signal_fraction, sparsity, tropical_support)
 *    T  = per-step update of sufficient stats
 *    φ  = algebra scores (low-rank, sparse, tropical, dense)
 *
 * All monitors are header-only, CPU-side, zero dependencies beyond STL.
 * They are designed to attach to SGF's training loop and emit health signals.
 */

#include "ire.h"
#include "welford.cuh"
#include <vector>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <cassert>
#include <cfloat>
#include <string>
#include <sstream>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Utilities: SVD-free spectral estimation
// For monitoring purposes, we use the following cheap proxies:
//   - Frobenius norm  ||W||_F  (O(mn))
//   - Nuclear norm approximation via power iteration (O(mn × iters))
//   - Row-column norm spectrum as a cheap SV proxy
// Full SVD is called explicitly only when the caller requests it.
// ─────────────────────────────────────────────────────────────────────────────

/// Compute Frobenius norm squared of a [rows × cols] matrix
inline float frobenius_sq(const float* W, int rows, int cols) {
    float s = 0.0f;
    for (int i = 0; i < rows * cols; ++i) s += W[i] * W[i];
    return s;
}

/// Power iteration to estimate σ_1 (largest singular value)
/// Returns σ_1 and stores the corresponding left/right singular vectors.
inline float power_iteration(const float* W, int rows, int cols,
                               int n_iters = 30,
                               float* u_out = nullptr,
                               float* v_out = nullptr)
{
    std::vector<float> v(cols, 1.0f / std::sqrt((float)cols));
    std::vector<float> u(rows);
    std::vector<float> tmp(std::max(rows, cols));

    float sigma = 0.0f;
    for (int iter = 0; iter < n_iters; ++iter) {
        // u = W v / ||W v||
        for (int i = 0; i < rows; ++i) {
            float s = 0.0f;
            for (int j = 0; j < cols; ++j)
                s += W[i * cols + j] * v[j];
            u[i] = s;
        }
        sigma = 0.0f;
        for (int i = 0; i < rows; ++i) sigma += u[i] * u[i];
        sigma = std::sqrt(sigma);
        if (sigma < 1e-12f) break;
        for (int i = 0; i < rows; ++i) u[i] /= sigma;

        // v = W^T u / ||W^T u||
        for (int j = 0; j < cols; ++j) {
            float s = 0.0f;
            for (int i = 0; i < rows; ++i)
                s += W[i * cols + j] * u[i];
            v[j] = s;
        }
        float vnorm = 0.0f;
        for (int j = 0; j < cols; ++j) vnorm += v[j] * v[j];
        vnorm = std::sqrt(vnorm);
        if (vnorm < 1e-12f) break;
        for (int j = 0; j < cols; ++j) v[j] /= vnorm;
    }
    if (u_out) std::copy(u.begin(), u.end(), u_out);
    if (v_out) std::copy(v.begin(), v.end(), v_out);
    return sigma;
}

/// Estimate top-r singular values via sequential deflation
/// (accurate for r << min(rows, cols); cost = O(r × n_iters × rows × cols))
inline std::vector<float> estimate_top_singular_values(
    const float* W, int rows, int cols, int r, int n_iters = 20)
{
    std::vector<float> svs;
    svs.reserve(r);
    std::vector<float> W_def(W, W + rows * cols); // deflation copy

    for (int k = 0; k < r; ++k) {
        std::vector<float> u(rows), v(cols);
        float sigma = power_iteration(W_def.data(), rows, cols, n_iters,
                                       u.data(), v.data());
        if (sigma < 1e-8f) break;
        svs.push_back(sigma);
        // Deflate: W -= sigma * u * v^T
        for (int i = 0; i < rows; ++i)
            for (int j = 0; j < cols; ++j)
                W_def[i * cols + j] -= sigma * u[i] * v[j];
    }
    return svs;
}

// ─────────────────────────────────────────────────────────────────────────────
// 1.  SpectralPowerLawMonitor
//
// Fits α in σ_k ∝ k^{-α} via online OLS on (log k, log σ_k).
//
// IRE:
//   M  = RealLine
//   S  = OLS sufficient statistics: (n, Σx, Σy, Σx², Σxy) where x=log k, y=log σ
//   T  = O(r) update when new SV spectrum is fed
//   φ  = α = -slope = -(n Σxy - Σx Σy) / (n Σx² - (Σx)²)
//
// Reference values from autopsy:
//   Dense MLP (prime task):  α ≈ 0.427
//   Low-rank constrained:    α ≈ 1.223  (higher α = healthier spectral structure)
//   Target / reference:      α ≈ 0.85   (Cypha HRNA)
// ─────────────────────────────────────────────────────────────────────────────
struct SpectralPowerLawMonitor
    : IREBase<SpectralPowerLawMonitor, double, double, RealLine>
{
    // OLS sufficient statistics
    double n_obs  = 0.0;
    double sum_x  = 0.0;  // Σ log k
    double sum_y  = 0.0;  // Σ log σ
    double sum_xx = 0.0;  // Σ (log k)²
    double sum_xy = 0.0;  // Σ log k · log σ
    int    layer_id = -1;

    // Running history for trend detection
    std::vector<float> alpha_history;
    static constexpr int HISTORY_LEN = 100;

    // Reference thresholds from the autopsy
    static constexpr float ALPHA_DENSE_REFERENCE = 0.427f;
    static constexpr float ALPHA_LOWRANK_TARGET  = 1.223f;
    static constexpr float ALPHA_CYPHA_REFERENCE = 0.85f;
    static constexpr float ALPHA_DATA_PRIOR      = 0.37f;

    void init(int layer = -1) {
        reset();
        layer_id = layer;
    }

    void reset() {
        n_obs = sum_x = sum_y = sum_xx = sum_xy = 0.0;
        alpha_history.clear();
    }

    /// IRE update: ingest a set of singular values for one layer snapshot.
    /// svs[0] is σ_1 (largest), svs[r-1] is σ_r (smallest).
    void observe(const std::vector<float>& svs) {
        for (int k = 0; k < (int)svs.size(); ++k) {
            if (svs[k] <= 0.0f) continue;
            double lk  = std::log((double)(k + 1));
            double ls  = std::log((double)svs[k]);
            n_obs  += 1.0;
            sum_x  += lk;
            sum_y  += ls;
            sum_xx += lk * lk;
            sum_xy += lk * ls;
        }
    }

    /// Observe directly from a weight matrix (computes SVs internally)
    void observe_matrix(const float* W, int rows, int cols,
                         int r = -1, int n_iters = 20)
    {
        if (r <= 0) r = std::min(rows, cols);
        r = std::min(r, std::min(rows, cols));
        auto svs = estimate_top_singular_values(W, rows, cols, r, n_iters);
        observe(svs);
    }

    /// IRE readout: α = -slope of log-log regression
    double readout() const {
        if (n_obs < 2.0) return 0.0;
        double denom = n_obs * sum_xx - sum_x * sum_x;
        if (std::abs(denom) < 1e-12) return 0.0;
        double slope = (n_obs * sum_xy - sum_x * sum_y) / denom;
        return -slope;  // α = -slope (SVs decay as k^{-α})
    }

    float alpha() const { return (float)readout(); }

    /// Record current α to history
    void checkpoint_alpha() {
        float a = alpha();
        alpha_history.push_back(a);
        if ((int)alpha_history.size() > HISTORY_LEN)
            alpha_history.erase(alpha_history.begin());
    }

    /// Classify spectral health relative to autopsy references
    enum class SpectralHealth {
        NOISE_DOMINATED,    // α < 0.37  (below data prior)
        DENSE_REGIME,       // 0.37 ≤ α < 0.60  (typical dense MLP)
        STRUCTURED,         // 0.60 ≤ α < 1.00  (healthy, near Cypha)
        HIGHLY_STRUCTURED,  // α ≥ 1.00  (low-rank constraint regime)
    };

    SpectralHealth health() const {
        float a = alpha();
        if (a < ALPHA_DATA_PRIOR)       return SpectralHealth::NOISE_DOMINATED;
        if (a < 0.60f)                  return SpectralHealth::DENSE_REGIME;
        if (a < 1.00f)                  return SpectralHealth::STRUCTURED;
        return                                 SpectralHealth::HIGHLY_STRUCTURED;
    }

    const char* health_str() const {
        switch (health()) {
            case SpectralHealth::NOISE_DOMINATED:   return "NOISE_DOMINATED";
            case SpectralHealth::DENSE_REGIME:      return "DENSE_REGIME";
            case SpectralHealth::STRUCTURED:        return "STRUCTURED";
            case SpectralHealth::HIGHLY_STRUCTURED: return "HIGHLY_STRUCTURED";
        }
        return "UNKNOWN";
    }

    /// IRE parallel merge: combine OLS stats from two monitors
    void merge(const SpectralPowerLawMonitor& other) {
        n_obs  += other.n_obs;
        sum_x  += other.sum_x;
        sum_y  += other.sum_y;
        sum_xx += other.sum_xx;
        sum_xy += other.sum_xy;
    }

    /// Check for monotone increasing α across layers (autopsy finding: 0.31→0.43→0.54)
    static bool alpha_increases_with_depth(
        const std::vector<SpectralPowerLawMonitor>& monitors)
    {
        for (int i = 1; i < (int)monitors.size(); ++i)
            if (monitors[i].alpha() <= monitors[i-1].alpha()) return false;
        return monitors.size() >= 2;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// 2.  MarchenkoPasturMonitor
//
// Tracks the Marchenko-Pastur bulk threshold and signal fraction.
// For a [d_out × d_in] weight matrix W with i.i.d. Gaussian entries:
//   MP bulk upper edge: σ_MP = σ_noise × (1 + sqrt(γ))²
//   where γ = d_out / d_in  (aspect ratio)
//
// Signal SVs are those above σ_MP; noise SVs are within the bulk.
//
// IRE:
//   M  = PSD (spectral distribution)
//   S  = (n, γ, σ²_noise_estimate, Frobenius_sq, n_signal_svs, signal_fro_sq)
//   T  = update when new SVs observed
//   φ  = signal_fraction = ||W_signal||²_F / ||W||²_F
//
// Autopsy result: signal_fraction = 0.242 (only 24.2% is genuine signal)
// ─────────────────────────────────────────────────────────────────────────────
struct MarchenkoPasturMonitor
    : IREBase<MarchenkoPasturMonitor, float, float, PSD>
{
    int   d_out      = 0;
    int   d_in       = 0;
    float gamma      = 1.0f;   // aspect ratio d_out / d_in
    float fro_sq     = 0.0f;   // ||W||²_F
    float sigma_noise = 0.0f;  // estimated noise level σ

    // Per-observation
    int   n_svs_total   = 0;
    int   n_svs_signal  = 0;
    float signal_fro_sq = 0.0f;
    float noise_fro_sq  = 0.0f;

    // Reference from autopsy
    static constexpr float AUTOPSY_SIGNAL_FRACTION = 0.242f;
    static constexpr float AUTOPSY_DOMINANT_SV_RATIO = 63.0f; // Layer 4: σ₁/σ_MP = 63

    void init(int out, int in) {
        d_out = out; d_in = in;
        gamma = (in > 0) ? (float)out / (float)in : 1.0f;
        reset();
    }

    void reset() {
        fro_sq = sigma_noise = 0.0f;
        n_svs_total = n_svs_signal = 0;
        signal_fro_sq = noise_fro_sq = 0.0f;
    }

    /// Estimate noise level from the bulk of the SV spectrum.
    /// Uses Median / MP-consistent estimator:
    ///   σ²_noise ≈ median(σ_k²) / (1 + sqrt(γ))²
    static float estimate_noise(const std::vector<float>& svs, float gamma) {
        if (svs.empty()) return 0.0f;
        std::vector<float> sv2(svs.size());
        for (size_t i = 0; i < svs.size(); ++i) sv2[i] = svs[i] * svs[i];
        std::vector<float> sorted_sv2(sv2);
        std::sort(sorted_sv2.begin(), sorted_sv2.end());
        float median_sv2 = sorted_sv2[sorted_sv2.size() / 2];
        float mp_bulk_max_sq = (1.0f + std::sqrt(gamma)) * (1.0f + std::sqrt(gamma));
        return std::sqrt(median_sv2 / mp_bulk_max_sq);
    }

    /// IRE update: ingest SV spectrum and classify signal vs noise
    void observe(const std::vector<float>& svs) {
        sigma_noise = estimate_noise(svs, gamma);
        float mp_edge = sigma_noise * (1.0f + std::sqrt(gamma));

        // Compute Frobenius and partition
        fro_sq = 0.0f;
        signal_fro_sq = 0.0f;
        noise_fro_sq  = 0.0f;
        n_svs_total   = (int)svs.size();
        n_svs_signal  = 0;

        for (float sv : svs) {
            float sv2 = sv * sv;
            fro_sq += sv2;
            if (sv > mp_edge) {
                signal_fro_sq += sv2;
                ++n_svs_signal;
            } else {
                noise_fro_sq += sv2;
            }
        }
    }

    /// IRE readout: signal fraction
    float readout() const {
        return (fro_sq > 1e-12f) ? signal_fro_sq / fro_sq : 0.0f;
    }

    float signal_fraction() const { return readout(); }

    /// MP bulk threshold for this layer
    float mp_threshold() const {
        return sigma_noise * (1.0f + std::sqrt(gamma));
    }

    /// Number of statistically significant (signal) singular values
    int n_signal() const { return n_svs_signal; }

    /// Dominant SV ratio: σ_1 / σ_MP (autopsy Layer 4: 63×)
    float dominant_ratio(const std::vector<float>& svs) const {
        if (svs.empty() || sigma_noise < 1e-12f) return 0.0f;
        return svs[0] / mp_threshold();
    }

    /// Check if this layer has a single dominant singular vector
    /// (matches autopsy Layer 4 finding: 1 SV at 63× threshold)
    bool has_dominant_direction(const std::vector<float>& svs,
                                 float ratio_threshold = 10.0f) const
    {
        return n_svs_signal >= 1 && dominant_ratio(svs) >= ratio_threshold;
    }

    /// Effective rank: number of SVs needed to capture 90% of Frobenius mass
    static int effective_rank_90(const std::vector<float>& svs) {
        float total_fro_sq = 0.0f;
        for (float sv : svs) total_fro_sq += sv * sv;
        float threshold = 0.9f * total_fro_sq;
        float cumulative = 0.0f;
        for (int k = 0; k < (int)svs.size(); ++k) {
            cumulative += svs[k] * svs[k];
            if (cumulative >= threshold) return k + 1;
        }
        return (int)svs.size();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// 3.  AlgebraClassifier
//
// Classifies the dominant algebra of a weight matrix based on spectral
// signatures from the autopsy. Outputs scores in [0,1] for each algebra class.
//
// IRE:
//   M  = probability simplex over {Low-Rank, Sparse, Tropical, Dense}
//   S  = (α, signal_fraction, sparsity_proxy, tropical_support)
//   T  = update when new (α, signal_fraction, ...) observations arrive
//   φ  = algebra scores + dominant class
//
// Score derivation (from autopsy empirical calibration):
//   low_rank_score  = sigmoid((α - α_dense) / 0.15)  × (1 - signal_fraction)
//   sparse_score    = sparsity × (1 - tropical_support)
//   tropical_score  = tropical_support
//   dense_score     = (1 - low_rank_score) × signal_fraction
// ─────────────────────────────────────────────────────────────────────────────
struct AlgebraScores {
    float low_rank  = 0.0f;
    float sparse    = 0.0f;
    float tropical  = 0.0f;
    float dense     = 0.0f;

    AlgebraTag::Kind dominant() const {
        float best = low_rank;
        AlgebraTag::Kind kind = AlgebraTag::Kind::LOW_RANK;
        if (sparse   > best) { best = sparse;   kind = AlgebraTag::Kind::SPARSE_CODING; }
        if (tropical > best) { best = tropical; kind = AlgebraTag::Kind::TROPICAL; }
        if (dense    > best) { best = dense;    kind = AlgebraTag::Kind::DENSE; }
        return kind;
    }

    const char* dominant_str() const {
        switch (dominant()) {
            case AlgebraTag::Kind::LOW_RANK:      return "LOW_RANK";
            case AlgebraTag::Kind::SPARSE_CODING: return "SPARSE_CODING";
            case AlgebraTag::Kind::TROPICAL:      return "TROPICAL";
            case AlgebraTag::Kind::DENSE:         return "DENSE";
            default:                               return "HYBRID";
        }
    }

    // Reference autopsy scores
    static AlgebraScores autopsy_reference() {
        return { 0.758f, 0.668f, 0.536f, 0.112f };
    }
};

struct AlgebraClassifier
    : IREBase<AlgebraClassifier, AlgebraScores, AlgebraScores,
              ProbabilitySimplex>
{
    // Sufficient statistics (online EMA)
    float ema_alpha              = 0.0f;
    float ema_signal_fraction    = 0.0f;
    float ema_sparsity           = 0.0f;
    float ema_tropical_support   = 0.0f;
    float ema_beta               = 0.95f;
    int   n_updates              = 0;

    // Per-layer spectral monitors
    SpectralPowerLawMonitor  alpha_monitor;
    MarchenkoPasturMonitor   mp_monitor;

    void init(int d_out, int d_in, float beta = 0.95f) {
        alpha_monitor.init();
        mp_monitor.init(d_out, d_in);
        ema_beta = beta;
        reset();
    }

    void reset() {
        ema_alpha = ema_signal_fraction = ema_sparsity = ema_tropical_support = 0.0f;
        n_updates = 0;
        alpha_monitor.reset();
        mp_monitor.reset();
    }

    /// IRE update: feed weight matrix + activation sparsity measurement
    void observe(const float* W, int d_out, int d_in,
                  float observed_sparsity = 0.54f,  // default: autopsy finding
                  int sv_rank = 16, int n_iters = 20)
    {
        // Update alpha monitor
        auto svs = estimate_top_singular_values(W, d_out, d_in, sv_rank, n_iters);
        alpha_monitor.observe(svs);
        mp_monitor.observe(svs);

        // Compute tropical support: fraction of columns that are "active" argmax targets
        // Proxy: fraction of columns with above-mean column norm
        float col_norm_mean = 0.0f;
        std::vector<float> col_norms(d_in, 0.0f);
        for (int j = 0; j < d_in; ++j) {
            float s = 0.0f;
            for (int i = 0; i < d_out; ++i)
                s += W[i * d_in + j] * W[i * d_in + j];
            col_norms[j] = std::sqrt(s);
            col_norm_mean += col_norms[j];
        }
        col_norm_mean /= (float)d_in;
        int n_active = 0;
        for (float cn : col_norms) if (cn > col_norm_mean) ++n_active;
        float tropical_support = (float)n_active / (float)d_in;

        // EMA updates
        float ob = 1.0f - ema_beta;
        if (n_updates == 0) {
            ema_alpha            = alpha_monitor.alpha();
            ema_signal_fraction  = mp_monitor.signal_fraction();
            ema_sparsity         = observed_sparsity;
            ema_tropical_support = tropical_support;
        } else {
            ema_alpha            = ema_beta * ema_alpha            + ob * alpha_monitor.alpha();
            ema_signal_fraction  = ema_beta * ema_signal_fraction  + ob * mp_monitor.signal_fraction();
            ema_sparsity         = ema_beta * ema_sparsity         + ob * observed_sparsity;
            ema_tropical_support = ema_beta * ema_tropical_support + ob * tropical_support;
        }
        ++n_updates;
        alpha_monitor.checkpoint_alpha();
    }

    /// IRE readout: algebra scores
    AlgebraScores readout() const {
        // Calibrated from autopsy (prime-task MLP)
        // low_rank: high when α > α_dense AND signal_fraction is low (noise-cancelled)
        float alpha_excess = ema_alpha - SpectralPowerLawMonitor::ALPHA_DENSE_REFERENCE;
        float lr_score = 1.0f / (1.0f + std::exp(-alpha_excess / 0.15f));
        lr_score *= (1.0f - ema_signal_fraction + 0.1f); // invert: low signal = more low-rank
        lr_score = std::min(1.0f, lr_score * 1.5f); // scale to [0,1]

        // sparse: high when activation sparsity is high AND tropical support is low
        float sp_score = ema_sparsity * (1.0f - 0.5f * ema_tropical_support);

        // tropical: high when tropical support fraction is high
        float tr_score = ema_tropical_support * 0.7f; // cap at 0.7 (never fully tropical)

        // dense: residual — high when signal fraction high + α near data prior
        float alpha_dist_from_dense = std::abs(ema_alpha - SpectralPowerLawMonitor::ALPHA_DENSE_REFERENCE);
        float dense_base = (1.0f - lr_score) * ema_signal_fraction;
        float d_score = dense_base * std::exp(-alpha_dist_from_dense / 0.3f);

        return { lr_score, sp_score, tr_score, d_score };
    }

    AlgebraScores scores() const { return readout(); }

    /// Derive an AlgebraTag for constructing the right layer type
    AlgebraTag to_algebra_tag(int d_out) const {
        auto s = scores();
        return AlgebraTag::from_autopsy_scores(
            s.low_rank, s.sparse, s.tropical, s.dense, d_out);
    }

    /// Check consistency with autopsy reference (prime-task baseline)
    bool matches_autopsy_reference(float tolerance = 0.15f) const {
        auto ref = AlgebraScores::autopsy_reference();
        auto cur = scores();
        return std::abs(cur.low_rank - ref.low_rank) < tolerance &&
               std::abs(cur.sparse   - ref.sparse)   < tolerance;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// 4.  LayerwiseSpectralReport
//
// Aggregates per-layer spectral monitors across a full network.
// Produces a human-readable health report and suggests layer-wise algebra.
// ─────────────────────────────────────────────────────────────────────────────
struct LayerwiseSpectralReport {
    struct LayerEntry {
        int   layer_id;
        int   d_out, d_in;
        float alpha;
        float signal_fraction;
        int   n_signal_svs;
        int   effective_rank;
        float dominant_sv_ratio;
        AlgebraScores scores;
        std::string health;
    };

    std::vector<LayerEntry> layers;

    /// Add a layer result
    void add_layer(int id, int d_out, int d_in,
                    const float* W,
                    float observed_sparsity = 0.54f,
                    int sv_rank = 16)
    {
        AlgebraClassifier clf;
        clf.init(d_out, d_in);
        clf.observe(W, d_out, d_in, observed_sparsity, sv_rank);

        auto svs = estimate_top_singular_values(W, d_out, d_in, sv_rank);

        LayerEntry e;
        e.layer_id         = id;
        e.d_out            = d_out;
        e.d_in             = d_in;
        e.alpha            = clf.ema_alpha;
        e.signal_fraction  = clf.mp_monitor.signal_fraction();
        e.n_signal_svs     = clf.mp_monitor.n_signal();
        e.effective_rank   = MarchenkoPasturMonitor::effective_rank_90(svs);
        e.dominant_sv_ratio = clf.mp_monitor.dominant_ratio(svs);
        e.scores           = clf.scores();
        e.health           = clf.alpha_monitor.health_str();
        layers.push_back(e);
    }

    /// Check autopsy finding: α increases monotonically with depth
    bool alpha_monotone_increasing() const {
        for (int i = 1; i < (int)layers.size(); ++i)
            if (layers[i].alpha <= layers[i-1].alpha) return false;
        return layers.size() >= 2;
    }

    /// Generate a formatted summary string
    std::string summary() const {
        std::ostringstream oss;
        oss << "=== Spectral Health Report ===\n";
        oss << "Layer  Shape        α      SigFrac  EffRank  DomRat  Health           DomAlgebra\n";
        oss << "----   -----------  -----  -------  -------  ------  ---------------  ----------\n";
        for (auto& e : layers) {
            char buf[256];
            std::snprintf(buf, sizeof(buf),
                "  %2d   %4d×%-4d  %5.3f  %6.3f   %4d     %6.1f  %-15s  %s\n",
                e.layer_id, e.d_out, e.d_in, e.alpha, e.signal_fraction,
                e.effective_rank, e.dominant_sv_ratio, e.health.c_str(),
                e.scores.dominant_str());
            oss << buf;
        }
        oss << "\nAlpha monotone with depth: " << (alpha_monotone_increasing() ? "YES" : "NO") << "\n";
        return oss.str();
    }

    /// Suggest low-rank rank for each layer based on effective rank
    std::vector<int> suggested_ranks() const {
        std::vector<int> ranks;
        for (auto& e : layers)
            ranks.push_back(std::max(1, e.effective_rank));
        return ranks;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// 5.  OnlineSpectralRegularizer
//
// Provides a regularisation signal to the training loop based on spectral
// health. Penalises layers whose α deviates from the Cypha HRNA reference.
//
// Regularisation loss addition:
//   L_spectral = λ × max(0, α_target - α_current)²
//
// This encourages the network toward the low-rank structured regime found
// in the autopsy's constrained variant (α = 1.223 vs dense α = 0.427).
// ─────────────────────────────────────────────────────────────────────────────
struct OnlineSpectralRegularizer {
    float lambda     = 1e-3f;   // regularisation strength
    float alpha_target = SpectralPowerLawMonitor::ALPHA_CYPHA_REFERENCE;

    std::vector<SpectralPowerLawMonitor> layer_monitors;

    void init(int n_layers, float reg_lambda = 1e-3f,
              float target_alpha = SpectralPowerLawMonitor::ALPHA_CYPHA_REFERENCE)
    {
        lambda = reg_lambda;
        alpha_target = target_alpha;
        layer_monitors.resize(n_layers);
        for (int i = 0; i < n_layers; ++i) layer_monitors[i].init(i);
    }

    /// Update monitors with current weight matrices
    void update(int layer_id, const float* W, int d_out, int d_in,
                 int sv_rank = 8, int n_iters = 15)
    {
        assert(layer_id < (int)layer_monitors.size());
        layer_monitors[layer_id].observe_matrix(W, d_out, d_in, sv_rank, n_iters);
    }

    /// Compute total spectral regularisation loss
    float regularisation_loss() const {
        float loss = 0.0f;
        for (auto& m : layer_monitors) {
            float a = m.alpha();
            float deficit = alpha_target - a;
            if (deficit > 0.0f) loss += deficit * deficit;
        }
        return lambda * loss;
    }

    /// Per-layer signal: how far below target α is this layer?
    float layer_deficit(int layer_id) const {
        float a = layer_monitors[layer_id].alpha();
        return std::max(0.0f, alpha_target - a);
    }

    /// Get recommended rank for each layer (effective_rank via 90% Frobenius)
    std::vector<int> recommended_ranks(const std::vector<const float*>& W_matrices,
                                        const std::vector<int>& d_outs,
                                        const std::vector<int>& d_ins,
                                        int sv_rank = 16) const
    {
        std::vector<int> ranks(W_matrices.size());
        for (int i = 0; i < (int)W_matrices.size(); ++i) {
            auto svs = estimate_top_singular_values(
                W_matrices[i], d_outs[i], d_ins[i], sv_rank);
            ranks[i] = MarchenkoPasturMonitor::effective_rank_90(svs);
        }
        return ranks;
    }
};

} // namespace sgf
