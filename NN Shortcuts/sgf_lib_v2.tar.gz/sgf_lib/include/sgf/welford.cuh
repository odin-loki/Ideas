#pragma once
/**
 * sgf/welford.cuh — Online mean and variance via Welford's algorithm
 *
 * IRE instance:
 *   M   = R (real line)
 *   S   = (n, mean, M2)           — three scalars
 *   T   = Welford update           — O(1), numerically stable
 *   phi = (mean, variance, std)    — read-out
 *
 * Also provides:
 *   - Parallel (Chan) merge for distributed computation
 *   - CUDA warp-level and block-level reductions
 *   - WelfordCUDA kernel for large tensors
 */

#include "ire.h"
#include <cmath>
#include <cstdint>

#ifdef __CUDACC__
#include <cuda_runtime.h>
#include <cuda_fp16.h>
#endif

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Host-side Welford state (also usable on device as plain struct)
// ─────────────────────────────────────────────────────────────────────────────
struct WelfordState {
    double mean  = 0.0;
    double M2    = 0.0;
    uint64_t n   = 0;

    SGF_HOST_DEVICE
    void update(double x) {
        ++n;
        double delta  = x - mean;
        mean         += delta / static_cast<double>(n);
        double delta2 = x - mean;
        M2           += delta * delta2;
    }

    SGF_HOST_DEVICE
    double variance()    const { return n > 1 ? M2 / static_cast<double>(n - 1) : 0.0; }

    SGF_HOST_DEVICE
    double variance_pop() const { return n > 0 ? M2 / static_cast<double>(n)     : 0.0; }

    SGF_HOST_DEVICE
    double std_dev()     const { return std::sqrt(variance()); }

    /// Chan's parallel merge: combine two independent Welford states exactly
    SGF_HOST_DEVICE
    static WelfordState merge(const WelfordState& a, const WelfordState& b) {
        if (a.n == 0) return b;
        if (b.n == 0) return a;
        WelfordState out;
        out.n    = a.n + b.n;
        double d = b.mean - a.mean;
        out.mean = a.mean + d * static_cast<double>(b.n) / static_cast<double>(out.n);
        out.M2   = a.M2 + b.M2 + d * d * static_cast<double>(a.n) *
                   static_cast<double>(b.n) / static_cast<double>(out.n);
        return out;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// Host-side Welford IRE component
// ─────────────────────────────────────────────────────────────────────────────
struct WelfordReadout {
    double mean;
    double variance;
    double std_dev;
};

class WelfordEstimator
    : public IREBase<WelfordEstimator, WelfordState, WelfordReadout, RealLineManifold>
{
public:
    void update_impl(double x)          { state_.update(x); }
    WelfordReadout readout_impl() const {
        return { state_.mean, state_.variance(), state_.std_dev() };
    }
    void merge_impl(const WelfordEstimator& o) {
        state_ = WelfordState::merge(state_, o.state_);
    }
    void reset_impl() { state_ = WelfordState{}; }

    const WelfordState& state() const { return state_; }

private:
    WelfordState state_;
};

// ─────────────────────────────────────────────────────────────────────────────
// CUDA warp-level Welford reduction (fits in 32 registers)
// ─────────────────────────────────────────────────────────────────────────────
#ifdef __CUDACC__

/// Warp-level parallel Welford merge using shuffle intrinsics.
/// Call from within a warp; all threads must participate.
__device__ __forceinline__
WelfordState warp_welford_reduce(WelfordState s) {
    // Use shfl_xor_sync to do butterfly reduction over 32 threads
    for (int offset = 16; offset >= 1; offset >>= 1) {
        WelfordState other;
        other.n    = __shfl_xor_sync(0xFFFFFFFF,
                         static_cast<unsigned long long>(s.n), offset);
        other.mean = __shfl_xor_sync(0xFFFFFFFF, s.mean, offset);
        other.M2   = __shfl_xor_sync(0xFFFFFFFF, s.M2,   offset);
        s = WelfordState::merge(s, other);
    }
    return s;
}

/// Block-level Welford reduction using shared memory.
/// Returns the merged state in thread 0; others return partial state.
__device__ __forceinline__
WelfordState block_welford_reduce(WelfordState s) {
    __shared__ WelfordState smem[32]; // one slot per warp

    int lane    = threadIdx.x & 31;
    int warp_id = threadIdx.x >> 5;

    // Step 1: reduce within each warp
    s = warp_welford_reduce(s);

    // Step 2: write warp result to shared memory
    if (lane == 0) smem[warp_id] = s;
    __syncthreads();

    // Step 3: reduce across warps in warp 0
    int n_warps = (blockDim.x + 31) >> 5;
    if (warp_id == 0) {
        WelfordState ws = (lane < n_warps) ? smem[lane] : WelfordState{};
        ws = warp_welford_reduce(ws);
        if (lane == 0) smem[0] = ws;
    }
    __syncthreads();
    return smem[0];
}

/// Kernel: compute Welford statistics for a flat fp32 tensor of length n.
/// Output: float3 {mean, variance, M2} written to d_out.
__global__
void welford_kernel_fp32(const float* __restrict__ d_in,
                          float* __restrict__ d_out,   // [3]: mean, var, M2
                          int n)
{
    WelfordState local;
    for (int i = blockIdx.x * blockDim.x + threadIdx.x; i < n;
         i += blockDim.x * gridDim.x)
    {
        local.update(static_cast<double>(d_in[i]));
    }
    WelfordState result = block_welford_reduce(local);
    if (threadIdx.x == 0 && blockIdx.x == 0) {
        d_out[0] = static_cast<float>(result.mean);
        d_out[1] = static_cast<float>(result.variance());
        d_out[2] = static_cast<float>(result.M2);
    }
}

/// Kernel: row-wise Welford normalisation (LayerNorm / RMSNorm building block).
/// Each block handles one row of shape [rows, cols].
/// Writes normalised values to d_out; optionally scales/biases with d_weight, d_bias.
__global__
void welford_layernorm_kernel_fp32(const float* __restrict__ d_in,
                                    float*       __restrict__ d_out,
                                    const float* __restrict__ d_weight,   // may be nullptr
                                    const float* __restrict__ d_bias,     // may be nullptr
                                    int rows, int cols,
                                    float eps)
{
    int row = blockIdx.x;
    if (row >= rows) return;

    const float* row_in  = d_in  + row * cols;
    float*       row_out = d_out + row * cols;

    // ── Step 1: compute mean and variance via block Welford ──
    WelfordState local;
    for (int c = threadIdx.x; c < cols; c += blockDim.x)
        local.update(static_cast<double>(row_in[c]));

    WelfordState result = block_welford_reduce(local);

    float mean    = static_cast<float>(result.mean);
    float inv_std = rsqrtf(static_cast<float>(result.variance()) + eps);

    // ── Step 2: normalise ──
    for (int c = threadIdx.x; c < cols; c += blockDim.x) {
        float norm = (row_in[c] - mean) * inv_std;
        if (d_weight) norm *= d_weight[c];
        if (d_bias)   norm += d_bias[c];
        row_out[c] = norm;
    }
}

/// Kernel: RMSNorm (no mean subtraction).
__global__
void welford_rmsnorm_kernel_fp32(const float* __restrict__ d_in,
                                  float*       __restrict__ d_out,
                                  const float* __restrict__ d_weight,
                                  int rows, int cols,
                                  float eps)
{
    int row = blockIdx.x;
    if (row >= rows) return;

    const float* row_in  = d_in  + row * cols;
    float*       row_out = d_out + row * cols;

    // Accumulate sum of squares
    float local_ss = 0.0f;
    for (int c = threadIdx.x; c < cols; c += blockDim.x)
        local_ss += row_in[c] * row_in[c];

    // Block reduce sum
    __shared__ float smem[32];
    int lane    = threadIdx.x & 31;
    int warp_id = threadIdx.x >> 5;

    for (int off = 16; off >= 1; off >>= 1)
        local_ss += __shfl_xor_sync(0xFFFFFFFF, local_ss, off);

    if (lane == 0) smem[warp_id] = local_ss;
    __syncthreads();

    if (warp_id == 0) {
        float ws = (lane < ((blockDim.x + 31) >> 5)) ? smem[lane] : 0.0f;
        for (int off = 16; off >= 1; off >>= 1)
            ws += __shfl_xor_sync(0xFFFFFFFF, ws, off);
        if (lane == 0) smem[0] = ws;
    }
    __syncthreads();

    float rms_inv = rsqrtf(smem[0] / static_cast<float>(cols) + eps);

    for (int c = threadIdx.x; c < cols; c += blockDim.x) {
        float val = row_in[c] * rms_inv;
        if (d_weight) val *= d_weight[c];
        row_out[c] = val;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Host launcher wrappers
// ─────────────────────────────────────────────────────────────────────────────
inline void launch_welford(const float* d_in, float* d_out, int n,
                            cudaStream_t stream = nullptr)
{
    int block = 256;
    int grid  = std::min((n + block - 1) / block, 65535);
    welford_kernel_fp32<<<grid, block, 0, stream>>>(d_in, d_out, n);
}

inline void launch_layernorm(const float* d_in, float* d_out,
                              const float* d_weight, const float* d_bias,
                              int rows, int cols, float eps = 1e-5f,
                              cudaStream_t stream = nullptr)
{
    int block = std::min(cols, 1024);
    welford_layernorm_kernel_fp32<<<rows, block, 0, stream>>>(
        d_in, d_out, d_weight, d_bias, rows, cols, eps);
}

inline void launch_rmsnorm(const float* d_in, float* d_out,
                            const float* d_weight,
                            int rows, int cols, float eps = 1e-6f,
                            cudaStream_t stream = nullptr)
{
    int block = std::min(cols, 1024);
    welford_rmsnorm_kernel_fp32<<<rows, block, 0, stream>>>(
        d_in, d_out, d_weight, rows, cols, eps);
}

#endif // __CUDACC__

} // namespace sgf
