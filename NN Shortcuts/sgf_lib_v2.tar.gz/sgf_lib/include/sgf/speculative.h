#pragma once
/**
 * sgf/speculative.h — Speculative decoding controller
 *
 * IRE instance:
 *   M    = Probability simplex (token distribution space)
 *   S    = draft distribution q   + acceptance EMA
 *   T    = draft_forward()        — generates k candidate tokens
 *   phi  = accept/reject via min(1, p_target / q_draft) per token
 *
 * Implements:
 *   - Standard speculative sampling (Leviathan et al. 2023)
 *   - Tree-structured speculative decoding (tree prefix sharing)
 *   - Self-speculative decoding (skip-layer drafting)
 *   - Online acceptance rate tracking (Welford-based)
 *
 * The acceptance rate alpha = E[min(1, p/q)] is the primary metric.
 * Throughput speedup ≈ (k * alpha + 1) / (1 + overhead_ratio)
 *
 * Integration: draft model can be a low-expert-count MoERouter (MoSE style).
 */

#include "ire.h"
#include "welford.cuh"
#include <vector>
#include <cmath>
#include <random>
#include <functional>
#include <cstdint>
#include <algorithm>
#include <cassert>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Token probability distribution (over vocab V)
// ─────────────────────────────────────────────────────────────────────────────
struct TokenDist {
    std::vector<float> probs;  // [V], sums to 1
    int vocab_size;

    explicit TokenDist(int V = 0) : probs(V, 0.0f), vocab_size(V) {}

    float operator[](int t) const { return probs[t]; }
    float& operator[](int t)      { return probs[t]; }
};

// ─────────────────────────────────────────────────────────────────────────────
// Speculative decoding result
// ─────────────────────────────────────────────────────────────────────────────
struct SpecResult {
    std::vector<int>   accepted_tokens;  // verified + accepted tokens
    int  n_drafted;                      // how many tokens the draft model proposed
    int  n_accepted;                     // how many were accepted
    float acceptance_rate;               // n_accepted / n_drafted
};

// ─────────────────────────────────────────────────────────────────────────────
// Speculative Decoder — manages one draft + one target model
// Models are represented as callables (λ, function pointer, or functor):
//   draft_fn  : (context) -> TokenDist   — fast, approximate
//   target_fn : (context, k tokens) -> vector<TokenDist>  — slow, accurate; batched
// ─────────────────────────────────────────────────────────────────────────────
struct SpeculativeConfig {
    int   k              = 4;
    float temperature    = 1.0f;
    bool  use_tree       = false;
    int   rng_seed       = 42;
};

class SpeculativeDecoder {
public:
    using Context    = std::vector<int>;
    using DraftFn    = std::function<TokenDist(const Context&)>;
    using TargetFn   = std::function<std::vector<TokenDist>(const Context&, const std::vector<int>&)>;
    using Config     = SpeculativeConfig;

    SpeculativeDecoder(DraftFn draft_fn, TargetFn target_fn, SpeculativeConfig cfg = SpeculativeConfig())
        : draft_(std::move(draft_fn))
        , target_(std::move(target_fn))
        , cfg_(cfg)
        , rng_(cfg.rng_seed)
    {}

    /// Generate one speculative step:
    /// 1. Draft k tokens from fast model
    /// 2. Run target model over all k+1 positions in parallel
    /// 3. Accept/reject each draft token via rejection sampling
    /// 4. Return all accepted tokens + one bonus from target
    SpecResult step(Context& ctx) {
        // ── Phase 1: draft k tokens ──
        std::vector<int>       draft_tokens;
        std::vector<TokenDist> draft_dists;
        Context draft_ctx = ctx;

        draft_tokens.reserve(cfg_.k);
        draft_dists.reserve(cfg_.k);

        for (int i = 0; i < cfg_.k; ++i) {
            TokenDist q = draft_(draft_ctx);
            int t = sample(q);
            draft_tokens.push_back(t);
            draft_dists.push_back(std::move(q));
            draft_ctx.push_back(t);
        }

        // ── Phase 2: verify with target (batch of k+1 positions) ──
        std::vector<TokenDist> target_dists = target_(ctx, draft_tokens);
        assert((int)target_dists.size() == cfg_.k + 1);

        // ── Phase 3: accept/reject each draft token ──
        SpecResult result;
        result.n_drafted = cfg_.k;
        int n_accepted   = 0;
        int bonus_pos    = cfg_.k;  // default: use last target distribution

        for (int i = 0; i < cfg_.k; ++i) {
            int   t_i = draft_tokens[i];
            float p_i = target_dists[i][t_i];
            float q_i = draft_dists[i][t_i];

            float acceptance_prob = std::min(1.0f, (q_i > 1e-10f) ? p_i / q_i : 0.0f);

            std::uniform_real_distribution<float> uniform(0.0f, 1.0f);
            if (uniform(rng_) < acceptance_prob) {
                // Accept
                result.accepted_tokens.push_back(t_i);
                ctx.push_back(t_i);
                ++n_accepted;
            } else {
                // Reject: sample from corrected distribution (p - q)^+
                // Then stop accepting further tokens
                bonus_pos = i;
                TokenDist corrected = corrected_dist(target_dists[i], draft_dists[i]);
                int bonus_token = sample(corrected);
                result.accepted_tokens.push_back(bonus_token);
                ctx.push_back(bonus_token);
                goto done;
            }
        }
        // All k accepted — sample one bonus token from target
        {
            int bonus = sample(target_dists[cfg_.k]);
            result.accepted_tokens.push_back(bonus);
            ctx.push_back(bonus);
        }
        done:

        result.n_accepted       = n_accepted;
        result.acceptance_rate  = static_cast<float>(n_accepted) /
                                   static_cast<float>(cfg_.k);

        // Update online acceptance statistics
        accept_stats_.update(static_cast<double>(result.acceptance_rate));
        ++total_steps_;

        return result;
    }

    /// Throughput multiplier estimate: (k * alpha + 1) / cost_ratio
    float throughput_multiplier(float target_cost_ratio = 10.0f) const {
        // cost_ratio = target_cost / draft_cost
        double alpha = accept_stats_.mean;
        double k     = cfg_.k;
        return static_cast<float>((k * alpha + 1.0) /
                                   (1.0 + k / target_cost_ratio));
    }

    double mean_acceptance_rate() const { return accept_stats_.mean; }
    double acceptance_std()       const { return accept_stats_.std_dev(); }
    uint64_t total_steps()        const { return total_steps_; }

private:
    int sample(const TokenDist& dist) {
        std::uniform_real_distribution<float> u(0.0f, 1.0f);
        float r = u(rng_) / cfg_.temperature;
        // Temperature sampling via cdf
        float cdf = 0.0f;
        for (int t = 0; t < dist.vocab_size; ++t) {
            cdf += dist[t];
            if (r < cdf) return t;
        }
        return dist.vocab_size - 1;
    }

    /// Corrected distribution: (p - q)^+ / Z
    TokenDist corrected_dist(const TokenDist& p, const TokenDist& q) {
        TokenDist out(p.vocab_size);
        float Z = 0.0f;
        for (int t = 0; t < p.vocab_size; ++t) {
            out[t] = std::max(0.0f, p[t] - q[t]);
            Z     += out[t];
        }
        if (Z > 1e-10f)
            for (int t = 0; t < p.vocab_size; ++t) out[t] /= Z;
        else
            out[0] = 1.0f; // fallback
        return out;
    }

    DraftFn  draft_;
    TargetFn target_;
    Config   cfg_;
    std::mt19937 rng_;
    WelfordState accept_stats_;
    uint64_t     total_steps_ = 0;
};

// ─────────────────────────────────────────────────────────────────────────────
// Data Quality Tracker (QQT scaling law IRE component)
//
// IRE instance:
//   M   = Data manifold (quality x redundancy space)
//   S   = (quality_welford, rep_count) per sample  — two scalars per datum
//   T   = update quality score and increment rep_count on re-encounter
//   phi = marginal_utility(S) = Q^gamma / (1 + lambda * rep_count)
// ─────────────────────────────────────────────────────────────────────────────
struct DataSampleState {
    float    quality_score = 1.0f;  // Q in [0, 1]: 1=clean, 0=noisy
    uint32_t rep_count     = 0;     // how many times this sample has been seen
};

struct QQTConfig {
    float gamma           = 0.7f;  // quality exponent (task-dependent)
    float rep_penalty_lam = 1.0f;  // repetition penalty strength
    float filter_threshold = 0.0f; // drop samples below this marginal utility
};

class DataQualityTracker {
public:
    explicit DataQualityTracker(QQTConfig cfg = {}) : cfg_(cfg) {}

    void record_observation(uint64_t sample_id, float quality) {
        auto& s = states_[sample_id];
        s.quality_score = quality;
        ++s.rep_count;
        quality_stats_.update(static_cast<double>(quality));
    }

    float marginal_utility(uint64_t sample_id) const {
        auto it = states_.find(sample_id);
        if (it == states_.end()) return 1.0f;  // unseen = max utility
        const auto& s = it->second;
        return std::pow(s.quality_score, cfg_.gamma) /
               (1.0f + cfg_.rep_penalty_lam * static_cast<float>(s.rep_count));
    }

    bool should_include(uint64_t sample_id) const {
        return marginal_utility(sample_id) > cfg_.filter_threshold;
    }

    double mean_quality()   const { return quality_stats_.mean; }
    double quality_std()    const { return quality_stats_.std_dev(); }
    uint64_t n_tracked()    const { return quality_stats_.n; }

    const QQTConfig& config() const { return cfg_; }

private:
    QQTConfig    cfg_;
    WelfordState quality_stats_;
    std::unordered_map<uint64_t, DataSampleState> states_;
};

} // namespace sgf
