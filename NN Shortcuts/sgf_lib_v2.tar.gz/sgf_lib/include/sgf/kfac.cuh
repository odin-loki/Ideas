#pragma once
/**
 * sgf/kfac.cuh — K-FAC Kronecker-Factored Approximate Curvature
 *
 * IRE instance:
 *   M    = PSD manifold (space of positive semi-definite matrices)
 *   S    = (A_l, G_l) per layer    — two small Kronecker factors
 *   T    = EMA of outer products   — A <- beta*A + (1-beta)*a*a^T
 *   phi  = Approximate F^{-1} g   — left/right preconditioner application
 *
 * For a linear layer y = W x:
 *   A_l  = EMA(x x^T)    — input covariance  [d_in  x d_in ]
 *   G_l  = EMA(ds ds^T)  — output grad covariance [d_out x d_out]
 *
 * Preconditioned gradient:
 *   G_l^{-1/4} * dW * A_l^{-1/4}
 *
 * where the -1/4 power is computed via eigen-decomposition.
 */

#include "ire.h"
#include <cstdint>
#include <cstring>
#include <cmath>
#include <vector>

#ifdef __CUDACC__
#include <cuda_runtime.h>
#include <cublas_v2.h>
#include <cusolverDn.h>
#endif

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Host-side Kronecker factor (small matrices, managed as flat vectors)
// ─────────────────────────────────────────────────────────────────────────────
struct KroneckerFactor {
    std::vector<float> data;  // [d x d] row-major
    int d = 0;
    float beta = 0.95f;
    bool  initialized = false;

    void init(int dim, float ema_beta = 0.95f) {
        d = dim; beta = ema_beta;
        data.assign((size_t)d * d, 0.0f);
        initialized = false;
    }

    /// EMA update with one outer product: F <- beta*F + (1-beta)*v*v^T
    void update(const float* v) {
        float ob = 1.0f - beta;
        if (!initialized) {
            // First update: set directly
            for (int i = 0; i < d; ++i)
                for (int j = 0; j < d; ++j)
                    data[i * d + j] = v[i] * v[j];
            initialized = true;
        } else {
            for (int i = 0; i < d; ++i)
                for (int j = 0; j < d; ++j)
                    data[i * d + j] = beta * data[i * d + j] + ob * v[i] * v[j];
        }
    }

    /// Parallel merge (Chan-style): combine two EMA factors
    void merge(const KroneckerFactor& other, float weight_self, float weight_other) {
        float total = weight_self + weight_other;
        for (size_t i = 0; i < data.size(); ++i)
            data[i] = (weight_self * data[i] + weight_other * other.data[i]) / total;
    }

    /// Compute matrix raised to power p using eigen-decomposition (CPU, small matrices)
    /// Result stored in `out` (must be pre-allocated [d x d])
    void matrix_power(float p, float* out, float damping = 1e-4f) const {
        // Use LAPACK-style Jacobi iteration (simplified: symmetric power iteration)
        // For production: use LAPACK dsyev or cuSolver for GPU variant
        std::vector<float> A(data); // copy
        std::vector<float> V(d * d, 0.0f); // eigenvectors
        for (int i = 0; i < d; ++i) V[i * d + i] = 1.0f; // identity

        // Simple Jacobi iterations for small symmetric matrices
        for (int sweep = 0; sweep < 100; ++sweep) {
            bool changed = false;
            for (int i = 0; i < d - 1; ++i) {
                for (int j = i + 1; j < d; ++j) {
                    float aij = A[i * d + j];
                    if (std::abs(aij) < 1e-10f) continue;
                    changed = true;
                    float aii = A[i * d + i], ajj = A[j * d + j];
                    float tau = (ajj - aii) / (2.0f * aij);
                    float t   = (tau >= 0) ?  1.0f / (tau + std::sqrt(1.0f + tau*tau))
                                           : -1.0f / (-tau + std::sqrt(1.0f + tau*tau));
                    float c   = 1.0f / std::sqrt(1.0f + t*t);
                    float s   = t * c;

                    // Jacobi rotation update
                    A[i*d+i] = aii - t*aij;
                    A[j*d+j] = ajj + t*aij;
                    A[i*d+j] = A[j*d+i] = 0.0f;
                    for (int k = 0; k < d; ++k) {
                        if (k != i && k != j) {
                            float aki = A[k*d+i], akj = A[k*d+j];
                            A[k*d+i] = A[i*d+k] = c*aki - s*akj;
                            A[k*d+j] = A[j*d+k] = s*aki + c*akj;
                        }
                        float vki = V[k*d+i], vkj = V[k*d+j];
                        V[k*d+i] = c*vki - s*vkj;
                        V[k*d+j] = s*vki + c*vkj;
                    }
                }
            }
            if (!changed) break;
        }

        // Eigenvalues are on diagonal of A; apply power
        // out = V * diag(lambda^p) * V^T
        std::vector<float> D(d, 0.0f);
        for (int i = 0; i < d; ++i)
            D[i] = std::pow(std::max(A[i*d+i], damping), p);

        for (int i = 0; i < d; ++i)
            for (int j = 0; j < d; ++j) {
                float s = 0.0f;
                for (int k = 0; k < d; ++k)
                    s += V[i*d+k] * D[k] * V[j*d+k];
                out[i*d+j] = s;
            }
    }
};

// ─────────────────────────────────────────────────────────────────────────────
// K-FAC layer state (CPU)
// ─────────────────────────────────────────────────────────────────────────────
struct KFACLayer {
    KroneckerFactor A;   // input covariance    [d_in  x d_in ]
    KroneckerFactor G;   // output-grad cov     [d_out x d_out]
    int d_in = 0, d_out = 0;
    int update_freq = 10;   // recompute inverses every N steps
    int step_count  = 0;

    std::vector<float> A_inv_sqrt;  // A^{-1/4}   [d_in  x d_in ]
    std::vector<float> G_inv_sqrt;  // G^{-1/4}   [d_out x d_out]
    bool factors_valid = false;

    void init(int in, int out, float beta = 0.95f, int freq = 10) {
        d_in = in; d_out = out; update_freq = freq;
        A.init(in,  beta);
        G.init(out, beta);
        A_inv_sqrt.resize((size_t)in  * in);
        G_inv_sqrt.resize((size_t)out * out);
    }

    /// Observe one (input, output_grad) pair and update Kronecker factors
    void observe(const float* a,  // [d_in]
                  const float* ds) // [d_out]
    {
        A.update(a);
        G.update(ds);
        ++step_count;
        if (step_count % update_freq == 0) recompute_inverses();
    }

    void recompute_inverses(float damping = 1e-4f) {
        A.matrix_power(-0.25f, A_inv_sqrt.data(), damping);
        G.matrix_power(-0.25f, G_inv_sqrt.data(), damping);
        factors_valid = true;
    }

    /// Apply K-FAC preconditioner to gradient matrix dW [d_out x d_in]
    /// Result: d_out = G^{-1/4} * dW * A^{-1/4}
    void precondition(const float* dW, float* out) const {
        if (!factors_valid) {
            std::memcpy(out, dW, (size_t)d_out * d_in * sizeof(float));
            return;
        }
        // Temp: T = dW * A^{-1/4}   [d_out x d_in]
        std::vector<float> tmp(d_out * d_in, 0.0f);
        for (int i = 0; i < d_out; ++i)
            for (int j = 0; j < d_in; ++j)
                for (int k = 0; k < d_in; ++k)
                    tmp[i * d_in + j] += dW[i * d_in + k] * A_inv_sqrt[k * d_in + j];

        // out = G^{-1/4} * T   [d_out x d_in]
        for (int i = 0; i < d_out; ++i)
            for (int j = 0; j < d_in; ++j)
                for (int k = 0; k < d_out; ++k)
                    out[i * d_in + j] += G_inv_sqrt[i * d_out + k] * tmp[k * d_in + j];
    }
};

#ifdef __CUDACC__

// ─────────────────────────────────────────────────────────────────────────────
// GPU Kronecker factor: EMA outer product update kernel
// ─────────────────────────────────────────────────────────────────────────────

/// Update: F[i,j] = beta * F[i,j] + (1-beta) * v[i] * v[j]
__global__
void kfac_ema_outer_kernel(float* F, const float* v,
                            float beta, float one_minus_beta,
                            int d)
{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= d * d) return;
    int i = idx / d, j = idx % d;
    F[idx] = beta * F[idx] + one_minus_beta * v[i] * v[j];
}

/// Batched outer product accumulation: update F with a mini-batch of vectors
/// v_batch: [batch x d], F: [d x d]
__global__
void kfac_batch_outer_kernel(float* F, const float* v_batch,
                               float beta, float one_minus_beta,
                               int batch, int d)
{
    int idx = blockIdx.x * blockDim.x + threadIdx.x;
    if (idx >= d * d) return;
    int ri = idx / d, ci = idx % d;

    // First: scale down existing F
    F[idx] *= beta;

    // Accumulate batch
    float acc = 0.0f;
    for (int b = 0; b < batch; ++b)
        acc += v_batch[b * d + ri] * v_batch[b * d + ci];
    F[idx] += one_minus_beta * acc / static_cast<float>(batch);
}

/// Apply preconditioner: out = inv_L * dW * inv_R
/// inv_L: [d_out x d_out], dW: [d_out x d_in], inv_R: [d_in x d_in]
__global__
void kfac_precondition_kernel(const float* __restrict__ inv_L,   // [d_out x d_out]
                                const float* __restrict__ dW,     // [d_out x d_in]
                                const float* __restrict__ inv_R,  // [d_in  x d_in]
                                float*       __restrict__ out,     // [d_out x d_in]
                                int d_out, int d_in)
{
    // Each thread computes one output element out[i,j]
    int i = blockIdx.y * blockDim.y + threadIdx.y;
    int j = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= d_out || j >= d_in) return;

    // Compute T[i,j] = sum_k dW[i,k] * inv_R[k,j]  (dW * inv_R)
    float t = 0.0f;
    for (int k = 0; k < d_in; ++k)
        t += dW[i * d_in + k] * inv_R[k * d_in + j];

    // out[i,j] = sum_k inv_L[i,k] * T[k,j]  (inv_L * T)
    float res = 0.0f;
    // T is implicit here — need two-pass or shared memory for large sizes
    // For simplicity, materialise T in a two-pass approach:
    // (production would use cuBLAS GEMM for each multiply)
    // Stored in out first pass, then read
    out[i * d_in + j] = t; // partial: T written first
    // Note: caller must do two separate GEMM calls via cuBLAS for large layers
}

struct KFACLayerGPU {
    float* d_A         = nullptr;  // [d_in  x d_in]
    float* d_G         = nullptr;  // [d_out x d_out]
    float* d_A_inv     = nullptr;  // A^{-1/4}
    float* d_G_inv     = nullptr;  // G^{-1/4}
    float* d_tmp       = nullptr;  // [d_out x d_in] scratch
    int d_in = 0, d_out = 0;
    int update_freq = 10, step_count = 0;
    float beta = 0.95f;
    cublasHandle_t   blas;
    cusolverDnHandle_t solver;

    void init(cublasHandle_t b, cusolverDnHandle_t s,
              int in, int out, float ema_beta = 0.95f, int freq = 10)
    {
        blas = b; solver = s;
        d_in = in; d_out = out; beta = ema_beta; update_freq = freq;
        SGF_CUDA_CHECK(cudaMalloc(&d_A,     (size_t)in  * in  * sizeof(float)));
        SGF_CUDA_CHECK(cudaMalloc(&d_G,     (size_t)out * out * sizeof(float)));
        SGF_CUDA_CHECK(cudaMalloc(&d_A_inv, (size_t)in  * in  * sizeof(float)));
        SGF_CUDA_CHECK(cudaMalloc(&d_G_inv, (size_t)out * out * sizeof(float)));
        SGF_CUDA_CHECK(cudaMalloc(&d_tmp,   (size_t)out * in  * sizeof(float)));
        SGF_CUDA_CHECK(cudaMemset(d_A, 0, (size_t)in  * in  * sizeof(float)));
        SGF_CUDA_CHECK(cudaMemset(d_G, 0, (size_t)out * out * sizeof(float)));
    }

    void observe_gpu(const float* d_a,  // [d_in]
                      const float* d_ds, // [d_out]
                      cudaStream_t stream = nullptr)
    {
        kfac_ema_outer_kernel<<<(d_in*d_in+255)/256, 256, 0, stream>>>(
            d_A, d_a, beta, 1.0f - beta, d_in);
        kfac_ema_outer_kernel<<<(d_out*d_out+255)/256, 256, 0, stream>>>(
            d_G, d_ds, beta, 1.0f - beta, d_out);
        ++step_count;
        if (step_count % update_freq == 0)
            recompute_inverses_gpu(stream);
    }

    /// Compute A^{-1/4} and G^{-1/4} via cuSolver eigen-decomposition
    void recompute_inverses_gpu(cudaStream_t stream = nullptr);

    /// Apply preconditioner via two cuBLAS GEMMs
    void precondition_gpu(const float* d_dW, float* d_out,
                           cudaStream_t stream = nullptr)
    {
        const float one = 1.0f, zero = 0.0f;
        // d_tmp = d_dW * d_A_inv   [d_out x d_in]
        SGF_CUBLAS_CHECK(cublasSgemm(blas, CUBLAS_OP_N, CUBLAS_OP_N,
            d_in, d_out, d_in,
            &one,  d_A_inv, d_in,
                   d_dW,    d_in,
            &zero, d_tmp,   d_in));

        // d_out = d_G_inv * d_tmp  [d_out x d_in]
        SGF_CUBLAS_CHECK(cublasSgemm(blas, CUBLAS_OP_N, CUBLAS_OP_N,
            d_in, d_out, d_out,
            &one,  d_tmp,   d_in,
                   d_G_inv, d_out,
            &zero, d_out,   d_in));
    }

    void free_mem() {
        cudaFree(d_A); cudaFree(d_G);
        cudaFree(d_A_inv); cudaFree(d_G_inv); cudaFree(d_tmp);
        d_A = d_G = d_A_inv = d_G_inv = d_tmp = nullptr;
    }
};

#endif // __CUDACC__

} // namespace sgf
