#pragma once
/**
 * sgf/ire.h — Incremental Riemannian Estimation (IRE) core abstractions
 *
 * Every component in the Streaming Geometry Framework is an IRE instance:
 *   (M, S, T, phi)
 *   M   = Riemannian manifold (parameter space, weight space, data space)
 *   S   = Sufficient statistic — compact O(1) or O(small) state
 *   T   = Online update rule: T(S_t, x_{t+1}) -> S_{t+1}
 *   phi = Read-out: phi(S) -> quantity of interest on M
 *
 * All concrete SGF components inherit from IREBase<StatType, ReadoutType>.
 */

#include <cstdint>
#include <type_traits>
#include <string>

namespace sgf {

// ─────────────────────────────────────────────────────────────────────────────
// Tag types for manifold classification
// ─────────────────────────────────────────────────────────────────────────────

struct EuclideanManifold {};        // Flat parameter space (SGD, Adam)
struct StiefelManifold {};          // Orthogonal matrices (Muon)
struct PSDManifold {};              // Positive semi-definite matrices (K-FAC)
struct ProbabilitySimplexManifold {};// Probability distributions (softmax, MoE)
struct RealLineManifold {};         // Scalar statistics (Welford, ZClip)
struct DataManifold {};             // Data quality/coverage space (QQT)

// ─────────────────────────────────────────────────────────────────────────────
// IREBase — CRTP base for all IRE components
// ─────────────────────────────────────────────────────────────────────────────
template <typename Derived, typename StatType, typename ReadoutType,
          typename ManifoldTag = EuclideanManifold>
class IREBase {
public:
    using stat_t    = StatType;
    using readout_t = ReadoutType;
    using manifold_t = ManifoldTag;

    /// Observe one new data point — calls T(S, x)
    template <typename ObsType>
    void observe(const ObsType& x) {
        static_cast<Derived*>(this)->update_impl(x);
        ++n_obs_;
    }

    /// Extract read-out phi(S)
    ReadoutType readout() const {
        return static_cast<const Derived*>(this)->readout_impl();
    }

    /// Merge two sufficient statistics (parallel Welford / K-FAC merge)
    void merge(const Derived& other) {
        static_cast<Derived*>(this)->merge_impl(other);
    }

    /// Number of observations accumulated so far
    uint64_t n_observations() const { return n_obs_; }

    /// Reset to prior state
    void reset() {
        static_cast<Derived*>(this)->reset_impl();
        n_obs_ = 0;
    }

protected:
    uint64_t n_obs_ = 0;
};

// ─────────────────────────────────────────────────────────────────────────────
// Device/Host annotation macros (compatible without CUDA if needed)
// ─────────────────────────────────────────────────────────────────────────────
#ifdef __CUDACC__
#  define SGF_HOST_DEVICE __host__ __device__
#  define SGF_DEVICE      __device__
#  define SGF_HOST        __host__
#else
#  define SGF_HOST_DEVICE
#  define SGF_DEVICE
#  define SGF_HOST
#endif

// ─────────────────────────────────────────────────────────────────────────────
// Error handling
// ─────────────────────────────────────────────────────────────────────────────
#ifdef __CUDACC__
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

#define SGF_CUDA_CHECK(call)                                               \
    do {                                                                    \
        cudaError_t err = (call);                                           \
        if (err != cudaSuccess) {                                           \
            fprintf(stderr, "CUDA error at %s:%d — %s\n",                  \
                    __FILE__, __LINE__, cudaGetErrorString(err));           \
            std::abort();                                                   \
        }                                                                   \
    } while (0)

#define SGF_CUBLAS_CHECK(call)                                             \
    do {                                                                    \
        cublasStatus_t st = (call);                                         \
        if (st != CUBLAS_STATUS_SUCCESS) {                                  \
            fprintf(stderr, "cuBLAS error %d at %s:%d\n",                  \
                    (int)st, __FILE__, __LINE__);                           \
            std::abort();                                                   \
        }                                                                   \
    } while (0)
#endif // __CUDACC__

} // namespace sgf
